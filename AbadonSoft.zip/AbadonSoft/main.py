"""
Abadon Soft — ассистент для пентеста

Ctrl+C - копировать
Ctrl+V - вставить
Shift (зажать) - выделение

Ctrl+A - удалить всю строку
Ctrl+Q - выход
"""

# ══════════════════════════════════════════════════════════════════
#  БЛОК 0. UAC
# ══════════════════════════════════════════════════════════════════
import os
import sys
import ctypes


def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return True


def _relaunch_as_admin():
    try:
        script = os.path.abspath(sys.argv[0])
        params = " ".join(f'"{a}"' for a in sys.argv[1:])
        ret = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable,
            f'"{script}" {params}'.strip(),
            None, 1,
        )
        return ret
    except Exception:
        return 0


if sys.platform == "win32" and not _is_admin():
    _ret = _relaunch_as_admin()
    if _ret <= 32:
        print()
        print("=" * 60)
        print("  Abadon Soft требует права администратора")
        print("=" * 60)
        print()
        print("  Ты отклонил запрос UAC, либо запуск не удался.")
        print()
        input("  Enter — выход...")
        sys.exit(1)
    sys.exit(0)


# ══════════════════════════════════════════════════════════════════
#  БЛОК 1. БУТСТРАП
# ══════════════════════════════════════════════════════════════════
import time
import shutil
import random
import subprocess
import importlib.util
import threading

IS_WIN = sys.platform == "win32"

if IS_WIN:
    try:
        os.system("chcp 65001 > nul 2>&1")
    except Exception:
        pass

for _name in ("stdout", "stderr"):
    _s = getattr(sys, _name, None)
    if _s is None:
        continue
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def _enable_ansi() -> bool:
    if not IS_WIN:
        return True
    try:
        import ctypes as _ct
        k = _ct.windll.kernel32
        h = k.GetStdHandle(-11)
        if not h or h == -1:
            return False
        mode = _ct.c_ulong()
        if not k.GetConsoleMode(h, _ct.byref(mode)):
            return False
        return bool(k.SetConsoleMode(h, mode.value | 0x0004))
    except Exception:
        return False


def _is_tty() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


_HAS_ANSI   = _enable_ansi()
_IS_TTY     = _is_tty()
_USE_MATRIX = _HAS_ANSI and _IS_TTY and ("--no-matrix" not in sys.argv)


R         = "\033[0m"
GREEN     = "\033[92m"
BGREEN    = "\033[1;92m"
DGREEN    = "\033[32m"
BRED      = "\033[1;91m"
BWHITE    = "\033[1;97m"
BPURPLE   = "\033[1;95m"
CYAN      = "\033[96m"
HIDE      = "\033[?25l"
SHOW      = "\033[?25h"
HOME      = "\033[H"
CLEAR     = "\033[2J"

MCHARS = ("ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎ"
          "ﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789")


def _term_size():
    try:
        s = shutil.get_terminal_size((80, 24))
        return max(40, s.columns), max(12, s.lines - 1)
    except Exception:
        return 80, 24


class _Drop:
    __slots__ = ("x", "y", "speed", "length", "chars")

    def __init__(self, x, rows):
        self.x = x
        self.y = random.randint(-25, 0)
        self.speed = random.choice([1, 1, 2, 2, 3])
        self.length = random.randint(5, 16)
        self.chars = [random.choice(MCHARS) for _ in range(self.length)]

    def step(self, rows):
        self.y += self.speed
        self.chars[0] = random.choice(MCHARS)
        if self.y - self.length > rows:
            self.y = random.randint(-25, -3)
            self.speed = random.choice([1, 1, 2, 2, 3])
            self.length = random.randint(5, 16)
            self.chars = [random.choice(MCHARS) for _ in range(self.length)]


def _render_frame(cols, rows, drops, hud_items):
    grid = [[" "] * cols for _ in range(rows)]
    colors = [[None] * cols for _ in range(rows)]

    for d in drops:
        for i in range(d.length):
            y = d.y - i
            if 0 <= y < rows and 0 <= d.x < cols:
                if i == 0:      colors[y][d.x] = BWHITE
                elif i <= 2:    colors[y][d.x] = BGREEN
                elif i <= 5:    colors[y][d.x] = GREEN
                else:           colors[y][d.x] = DGREEN
                grid[y][d.x] = d.chars[i]

    if hud_items:
        for hx, hy, text, color in hud_items:
            for i, ch in enumerate(text):
                x = hx + i
                if 0 <= hy < rows and 0 <= x < cols:
                    grid[hy][x] = ch
                    colors[hy][x] = color

    lines = []
    for y in range(rows):
        line, cur = [], None
        for x in range(cols):
            c = colors[y][x]
            if c != cur:
                line.append(c if c else R)
                cur = c
            line.append(grid[y][x])
        line.append(R)
        lines.append("".join(line))
    return "\n".join(lines)


def _build_hud(cols, rows, title, message, progress, subtitle=None):
    items = []
    cy, cx = rows // 2, cols // 2

    t = f" ⟦ {title} ⟧ "
    tx = cx - len(t) // 2
    items.append((tx, cy - 5, t, BRED))
    items.append((tx, cy - 4, "═" * len(t), DGREEN))

    mx = cx - len(message) // 2
    items.append((mx, cy - 2, message, BWHITE))

    bar_w = min(60, max(20, cols - 24))
    p = max(0.0, min(1.0, progress))
    filled = int(bar_w * p)
    bx = cx - bar_w // 2
    items.append((bx, cy + 1, "█" * filled + "░" * (bar_w - filled), BRED))
    items.append((bx + bar_w + 2, cy + 1, f" {int(p*100):>3d}% ", BPURPLE))

    if subtitle:
        sx = cx - len(subtitle) // 2
        items.append((sx, cy + 3, subtitle, CYAN))

    return items


def _run_matrix(get_hud, stop_flag=None, max_duration=None):
    cols, rows = _term_size()
    drops = [_Drop(x, rows) for x in range(cols)]

    try:
        sys.stdout.write(HIDE + CLEAR + HOME)
        sys.stdout.flush()
    except Exception:
        return

    start = time.time()
    try:
        while True:
            elapsed = time.time() - start
            if max_duration and elapsed > max_duration:
                break
            if stop_flag and stop_flag():
                break

            for d in drops:
                d.step(rows)

            title, message, progress, subtitle = get_hud(elapsed)
            hud = _build_hud(cols, rows, title, message, progress, subtitle)
            frame = _render_frame(cols, rows, drops, hud)

            try:
                sys.stdout.write(HOME + frame)
                sys.stdout.flush()
            except Exception:
                return

            time.sleep(0.05)
    finally:
        try:
            sys.stdout.write(R + SHOW)
            sys.stdout.flush()
        except Exception:
            pass


def _reset_terminal():
    try:
        sys.stdout.write(R + SHOW + CLEAR + HOME)
        sys.stdout.flush()
    except Exception:
        pass


NPCAP_EXE_NAMES = ["npcap-1.89.exe", "npcap-1.88.exe",
                   "npcap-1.87.exe", "npcap.exe"]


def _npcap_installed() -> bool:
    if not IS_WIN:
        return True
    root = os.environ.get("SystemRoot", r"C:\Windows")
    for sub in ("System32", "SysWOW64"):
        if os.path.isfile(os.path.join(root, sub, "wpcap.dll")):
            return True
    return False


def _find_npcap_exe():
    here = os.path.dirname(os.path.abspath(__file__))
    for d in (here, os.getcwd(),
              os.path.join(here, "installers"),
              os.path.join(here, "tools")):
        for name in NPCAP_EXE_NAMES:
            p = os.path.join(d, name)
            if os.path.isfile(p):
                return p
    return None


def _install_npcap_silent(exe_path):
    try:
        r = subprocess.run([exe_path, "/S", "/winpcap_mode=yes"],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            return False, (r.stdout or "") + (r.stderr or "")
        return True, ""
    except Exception as e:
        return False, str(e)


REQUIRED = [
    ("textual",  "textual>=0.80"),
    ("rich",     "rich>=13.0"),
    ("pywifi",   "pywifi>=1.1.12"),
    ("comtypes", "comtypes>=1.2"),
    ("paramiko", "paramiko>=3.0"),
    ("requests", "requests>=2.31"),
    ("scapy",    "scapy>=2.5"),
]


def _has(mod: str) -> bool:
    try:
        return importlib.util.find_spec(mod) is not None
    except Exception:
        return False


def _install(pip_spec: str):
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", pip_spec],
            capture_output=True, text=True, timeout=600,
        )
        if r.returncode != 0:
            return False, (r.stdout or "") + (r.stderr or "")
        return True, ""
    except Exception as e:
        return False, str(e)


def _phase_npcap():
    if not IS_WIN:
        return True
    if _npcap_installed():
        return True
    exe = _find_npcap_exe()
    if not exe:
        return "no-exe"

    def hud(elapsed):
        return ("A B A D O N   S O F T",
                "installing  Npcap  driver ...",
                min(elapsed / 8.0, 0.95),
                "[ local: npcap-1.89.exe · WinPcap mode ]")

    if _USE_MATRIX:
        result = {"ok": None, "err": ""}

        def worker():
            ok, err = _install_npcap_silent(exe)
            result["ok"] = ok
            result["err"] = err

        th = threading.Thread(target=worker, daemon=True)
        th.start()
        _run_matrix(hud, stop_flag=lambda: not th.is_alive(),
                    max_duration=60.0)
        th.join(timeout=5)
        ok = result.get("ok")
        err = result.get("err", "")
    else:
        print("  → ставим Npcap (тихо)…")
        ok, err = _install_npcap_silent(exe)

    if ok:
        def ok_hud(elapsed):
            return ("A B A D O N   S O F T", "Npcap installed", 1.0,
                    "[ restarting... ]")
        if _USE_MATRIX:
            _run_matrix(ok_hud, max_duration=1.0)
        return True
    return ("fail", err)


def boot():
    try:
        status = _phase_npcap()
        if status is True or status == "no-exe":
            pass
        elif isinstance(status, tuple) and status[0] == "fail":
            _reset_terminal()
            print()
            print(f"{BRED}[!] Не удалось поставить Npcap автоматически{R}")
            print(f"    {status[1]}")
            input("  Enter — продолжаем без Npcap...")

        missing = [(mod, spec) for mod, spec in REQUIRED if not _has(mod)]

        def intro_hud(elapsed):
            if elapsed < 0.6:    msg = "initializing core..."
            elif elapsed < 1.2:  msg = "loading modules..."
            elif elapsed < 1.8:  msg = "scanning environment..."
            else:                msg = "establishing link..."
            return ("A B A D O N   S O F T", msg, min(elapsed / 2.0, 1.0),
                    "[ abadon@soft — secure shell ]")

        if _USE_MATRIX:
            _run_matrix(intro_hud, max_duration=2.0)
        else:
            print("=== ABADON SOFT ===")
            for step in ("initializing core", "loading modules",
                         "scanning environment", "establishing link"):
                print(f"  → {step}")
                time.sleep(0.15)

        if not missing:
            def ready_hud(elapsed):
                return ("A B A D O N   S O F T", "SYSTEM READY", 1.0,
                        "[ abadon@soft ]")
            if _USE_MATRIX:
                _run_matrix(ready_hud, max_duration=0.9)
            _reset_terminal()
            return

        state = {"idx": 0, "results": {}, "errors": {}}

        def worker():
            for i, (mod, spec) in enumerate(missing):
                state["idx"] = i
                ok, err = _install(spec)
                state["results"][spec] = ok
                if not ok:
                    state["errors"][spec] = err
            state["idx"] = len(missing)

        th = threading.Thread(target=worker, daemon=True)
        th.start()

        def install_hud(elapsed):
            total = len(missing)
            idx = state["idx"]
            if idx >= total:
                p, msg = 1.0, "finalizing..."
            else:
                p = idx / total
                msg = f"installing  {missing[idx][0]}..."
            sub = f"pip · package {min(idx+1, total)}/{total} · do not close"
            return ("A B A D O N   S O F T", msg, p, sub)

        if _USE_MATRIX:
            _run_matrix(install_hud, stop_flag=lambda: not th.is_alive())
        else:
            print("=== INSTALLING DEPENDENCIES ===")
            th.join(timeout=900)

        def done_hud(elapsed):
            return ("A B A D O N   S O F T", "install complete", 1.0,
                    "[ restarting abadon... ]")
        if _USE_MATRIX:
            _run_matrix(done_hud, max_duration=1.0)

        th.join(timeout=30)
        _reset_terminal()

        failed = [spec for spec, ok in state["results"].items() if not ok]
        if failed:
            print()
            print(f"{BRED}[!] не удалось поставить: {', '.join(failed)}{R}")
            for spec in failed:
                err = state["errors"].get(spec, "")
                for line in (err or "").splitlines()[-8:]:
                    print(f"    {line}")
            input("\nEnter — выход...")
            sys.exit(1)

        try:
            subprocess.Popen([sys.executable, *sys.argv])
        except Exception:
            try:
                os.execv(sys.executable, [sys.executable, *sys.argv])
            except Exception:
                pass
        sys.exit(0)

    except KeyboardInterrupt:
        _reset_terminal()
        print("Aborted.")
        sys.exit(1)
    except Exception:
        _reset_terminal()
        import traceback
        traceback.print_exc()
        input("\nEnter — выход...")
        sys.exit(1)


boot()


# ══════════════════════════════════════════════════════════════════
#  БЛОК 2. ИМПОРТЫ
# ══════════════════════════════════════════════════════════════════
try:
    import random
    import queue
    import json
    import importlib.util
    from datetime import datetime

    from textual.app import App, ComposeResult
    from textual.containers import Horizontal, VerticalScroll, Container
    from textual.widgets import Static, Input, RichLog
    from textual.binding import Binding
    from textual.screen import ModalScreen
    from textual.message import Message
except Exception as e:
    print(f"\n[!] Не удалось импортировать: {e}")
    input("\nEnter — выход...")
    sys.exit(1)


# ══════════════════════════════════════════════════════════════════
#  БУФЕР ОБМЕНА WINDOWS — с правильными ctypes-прототипами!
# ══════════════════════════════════════════════════════════════════

if sys.platform == "win32":
    _user32   = ctypes.windll.user32
    _kernel32 = ctypes.windll.kernel32

    _user32.OpenClipboard.argtypes  = [ctypes.c_void_p]
    _user32.OpenClipboard.restype   = ctypes.c_bool

    _user32.EmptyClipboard.argtypes = []
    _user32.EmptyClipboard.restype  = ctypes.c_bool

    _user32.CloseClipboard.argtypes = []
    _user32.CloseClipboard.restype  = ctypes.c_bool

    _user32.GetClipboardData.argtypes = [ctypes.c_uint]
    _user32.GetClipboardData.restype  = ctypes.c_void_p

    _user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    _user32.SetClipboardData.restype  = ctypes.c_void_p

    _kernel32.GlobalAlloc.argtypes  = [ctypes.c_uint, ctypes.c_size_t]
    _kernel32.GlobalAlloc.restype   = ctypes.c_void_p

    _kernel32.GlobalLock.argtypes   = [ctypes.c_void_p]
    _kernel32.GlobalLock.restype    = ctypes.c_void_p

    _kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    _kernel32.GlobalUnlock.restype  = ctypes.c_bool

    _kernel32.GlobalFree.argtypes   = [ctypes.c_void_p]
    _kernel32.GlobalFree.restype    = ctypes.c_void_p


def _copy_to_clipboard(text: str) -> bool:
    if sys.platform != "win32":
        return False
    try:
        CF_UNICODETEXT = 13
        GMEM_MOVEABLE  = 0x0002
        if not _user32.OpenClipboard(None):
            return False
        try:
            _user32.EmptyClipboard()
            buf_size = (len(text) + 1) * 2
            h_mem = _kernel32.GlobalAlloc(GMEM_MOVEABLE, buf_size)
            if not h_mem:
                return False
            ptr = _kernel32.GlobalLock(h_mem)
            if not ptr:
                _kernel32.GlobalFree(h_mem)
                return False
            try:
                ctypes.memmove(ptr, text.encode("utf-16-le") + b"\x00\x00",
                               buf_size)
            finally:
                _kernel32.GlobalUnlock(h_mem)
            if not _user32.SetClipboardData(CF_UNICODETEXT, h_mem):
                _kernel32.GlobalFree(h_mem)
                return False
            return True
        finally:
            _user32.CloseClipboard()
    except Exception:
        return False


def _get_from_clipboard() -> str:
    if sys.platform != "win32":
        return ""
    try:
        CF_UNICODETEXT = 13
        opened = False
        for _ in range(5):
            if _user32.OpenClipboard(None):
                opened = True
                break
            time.sleep(0.05)
        if not opened:
            return ""
        try:
            handle = _user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = _kernel32.GlobalLock(handle)
            if not ptr:
                return ""
            try:
                text = ctypes.wstring_at(ptr)
                return text or ""
            finally:
                _kernel32.GlobalUnlock(handle)
        finally:
            _user32.CloseClipboard()
    except Exception:
        return ""


# ══════════════════════════════════════════════════════════════════
#  БЛОК 3. ТЕМА / ТЕКСТЫ / МОДУЛИ
# ══════════════════════════════════════════════════════════════════
BG           = "#0d0710"
DARK_RED     = "#4a0d12"
BLOOD        = "#8b1a1a"
VIOLET_DARK  = "#2b0f3a"
VIOLET       = "#5a2a82"
VIOLET_LIGHT = "#a06cd5"
TEXT_RED     = "#c93a3a"
TEXT_VIOLET  = "#b794f4"
NEON         = "#e94b4b"

GREETINGS = [
    "Всегда готов", "На месте", "Твой ход", "Система на связи",
    "Готов к работе", "Всегда готов", "Abadon на линии",
    "Ассистент загружен", "Инструменты наготове", "Я в деле",
]

ASSISTANT_ACK = [
    "Принял", "Понял", "Сейчас", "Запускаю", "Взял в работу",
    "Уже делаю", "Приступаю",
]

ASSISTANT_DONE = [
    "Готово", "Сделано", "Завершил", "Отработал",
    "Закончил", "Выполнено",
]

ASSISTANT_ERR = [
    "Хм, осечка", "Не получилось", "Ошибка", "Что-то сломалось",
    "Упс",
]

BANNER = r"""
 ▄▄▄       ▄▄▄▄    ▄▄▄       ▓█████▄  ▒█████   ███▄    █ 
▒████▄    ▓█████▄ ▒████▄     ▒██▀ ██▌▒██▒  ██▒ ██ ▀█   █ 
▒██  ▀█▄  ▒██▒ ▄██▒██  ▀█▄   ░██   █▌▒██░  ██▒▓██  ▀█ ██▒
░██▄▄▄▄██ ▒██░█▀  ░██▄▄▄▄██  ░▓█▄   ▌▒██   ██░▓██▒  ▐▌██▒
 ▓█   ▓██▒░▓█  ▀█▓ ▓█   ▓██▒ ░▒████▓ ░ ████▓▒░▒██░   ▓██░
 ░▒   ▓▒█░░▒▓███▀▒ ░▒   ▓▒█░  ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ 

 version 27092026/1552
"""


def _discover_modules():
    result = []
    here = os.path.dirname(os.path.abspath(__file__))
    mods_dir = os.path.join(here, "modules")
    if not os.path.isdir(mods_dir):
        return result

    for fname in sorted(os.listdir(mods_dir)):
        if not fname.endswith(".py") or fname.startswith("_"):
            continue
        mod_path = os.path.join(mods_dir, fname)
        mod_name = f"abadon_mod_{fname[:-3]}"
        try:
            spec = importlib.util.spec_from_file_location(mod_name, mod_path)
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if not hasattr(module, "NAME") or not hasattr(module, "run"):
                continue
            result.append({
                "name":    getattr(module, "NAME"),
                "title":   getattr(module, "TITLE", module.NAME),
                "desc":    getattr(module, "DESC", ""),
                "usage":   getattr(module, "USAGE", module.NAME),
                "aliases": getattr(module, "ALIASES", []),
                "module":  module,
            })
        except Exception as e:
            print(f"[!] Не смог загрузить модуль {fname}: {e}")
    return result


MODULES = _discover_modules()


def get_module(name: str):
    name = name.lower()
    for m in MODULES:
        if m["name"] == name:
            return m
        if name in m.get("aliases", []):
            return m
    return None


def help_text() -> str:
    if not MODULES:
        return "[#c93a3a]◆ модули не найдены (папка modules/ пуста)[/]"
    lines = ["[#c93a3a][b]◆ доступные модули:[/b][/]"]
    for m in MODULES:
        al = m.get("aliases") or []
        alias_str = ("  [dim](алиасы: " + ", ".join(al) + ")[/]") if al else ""
        lines.append(
            f"  [#a06cd5]{m['name']:<8}[/] [dim]—[/] {m['desc']}{alias_str}\n"
            f"           [#2b0f3a]└─[/] [dim]{m['usage']}[/]"
        )
    lines.append("  [#a06cd5]main[/]     [dim]— вернуться в главное меню[/]")
    lines.append("  [#a06cd5]menu[/]     [dim]— список модулей (диалог)[/]")
    lines.append("  [#a06cd5]clear[/]    [dim]— очистить консоль[/]")
    lines.append("  [#a06cd5]stop[/]     [dim]— остановить активный модуль[/]")
    lines.append("  [#a06cd5]exit[/]     [dim]— выход[/]")
    lines.append("")
    lines.append("[#c93a3a][b]◆ горячие клавиши в поле ввода:[/b][/]")
    lines.append("  [b]Ctrl+A[/b]  [dim]— очистить строку[/]")
    lines.append("  [b]Ctrl+U[/b]  [dim]— очистить строку[/]")
    lines.append("  [b]Ctrl+W[/b]  [dim]— удалить последнее слово[/]")
    lines.append("  [b]Ctrl+K[/b]  [dim]— удалить до конца строки[/]")
    lines.append("  [b]Ctrl+V[/b]  [dim]— вставить из буфера[/]")
    return "\n".join(lines)


class _StopFlag:
    def __init__(self):
        self._flag = False

    def request(self):
        self._flag = True

    def clear(self):
        self._flag = False

    def __call__(self) -> bool:
        return self._flag


# ══════════════════════════════════════════════════════════════════
#  INPUT С READLINE-ХОТКЕЯМИ
# ══════════════════════════════════════════════════════════════════

class AbadonInput(Input):
    """
    Input с дополнительными горячими клавишами:

      Ctrl+A — очистить всю строку (аналог "выделить всё + удалить")
      Ctrl+U — очистить всю строку (readline-классика)
      Ctrl+W — удалить последнее слово
      Ctrl+K — удалить от курсора до конца строки
      Ctrl+Backspace — удалить последнее слово
    """

    BINDINGS = [
        Binding("ctrl+a",         "line_clear",   "Очистить",         show=False),
        Binding("ctrl+u",         "line_clear",   "Очистить",         show=False),
        Binding("ctrl+w",         "word_delete",  "Удалить слово",    show=False),
        Binding("ctrl+k",         "kill_to_end",  "Удалить до конца", show=False),
        Binding("ctrl+backspace", "word_delete",  "",                 show=False),
    ]

    def action_line_clear(self) -> None:
        """Очистить всю строку."""
        self.value = ""
        try:
            self.cursor_position = 0
        except Exception:
            pass

    def action_word_delete(self) -> None:
        """Удалить последнее слово перед курсором."""
        val = self.value or ""
        if not val:
            return
        pos = self.cursor_position
        if pos is None or pos < 0:
            pos = len(val)

        before = val[:pos]
        after  = val[pos:]

        # убираем пробелы в конце before, потом ещё одно слово
        trimmed = before.rstrip()
        if " " in trimmed:
            new_before = trimmed.rsplit(" ", 1)[0] + " "
        else:
            new_before = ""

        self.value = new_before + after
        try:
            self.cursor_position = len(new_before)
        except Exception:
            pass

    def action_kill_to_end(self) -> None:
        """Удалить всё от курсора до конца строки."""
        val = self.value or ""
        pos = self.cursor_position
        if pos is None or pos < 0:
            pos = len(val)
        self.value = val[:pos]


# ══════════════════════════════════════════════════════════════════
#  ЭКРАН КОПИРОВАНИЯ (для модулей)
# ══════════════════════════════════════════════════════════════════

class CopyRow(Static):
    class Pressed(Message):
        def __init__(self, text: str) -> None:
            super().__init__()
            self.text = text

    def __init__(self, text: str, display: str = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self._text = text
        self._display = display if display is not None else text

    def on_mount(self) -> None:
        self.update(self._display)

    def on_click(self) -> None:
        self.post_message(self.Pressed(self._text))


class CopyScreen(ModalScreen):
    CSS = """
    CopyScreen {
        align: center middle;
        background: rgba(0, 0, 0, 0.85);
    }
    #copy-box {
        width: 94;
        height: 88%;
        background: #2b0f3a;
        border: heavy #8b1a1a;
        padding: 1 2;
    }
    #copy-title {
        text-align: center;
        color: #c93a3a;
        text-style: bold;
        padding: 0 0 1 0;
    }
    #copy-sub {
        text-align: center;
        color: #a06cd5;
        padding: 0 0 1 0;
    }
    #copy-scroll {
        height: 1fr;
        background: #0d0710;
        border: round #5a2a82;
    }
    .copy-row {
        width: 100%;
        height: 1;
        color: #b794f4;
        padding: 0 1;
        background: #0d0710;
    }
    .copy-row:hover {
        background: #8b1a1a;
        color: #c93a3a;
        text-style: bold;
    }
    .copy-all {
        color: #e94b4b;
        text-style: bold;
        background: #4a0d12;
    }
    .copy-all:hover {
        background: #8b1a1a;
        color: #ffffff;
    }
    .copy-spacer {
        height: 1;
        background: #0d0710;
    }
    #copy-hint {
        text-align: center;
        color: #5a2a82;
        padding: 1 0 0 0;
    }
    """

    def __init__(self, title: str, lines: list):
        super().__init__()
        self._title = title
        self._lines = lines

    def compose(self) -> ComposeResult:
        with Container(id="copy-box"):
            yield Static(f"◆ {self._title}", id="copy-title")
            yield Static(
                "клик по строке — копирует её · Esc — закрыть",
                id="copy-sub"
            )

            with VerticalScroll(id="copy-scroll"):
                if len(self._lines) > 1:
                    yield CopyRow(
                        "\n".join(self._lines),
                        "⧉  СКОПИРОВАТЬ ВСЁ ЦЕЛИКОМ",
                        classes="copy-row copy-all"
                    )
                    yield Static("", classes="copy-spacer")

                for line in self._lines:
                    if not line.strip():
                        yield Static("", classes="copy-spacer")
                        continue
                    yield CopyRow(line, line, classes="copy-row")

            yield Static("[dim]Esc — закрыть[/]", id="copy-hint")

    def on_copy_row_pressed(self, msg: CopyRow.Pressed) -> None:
        ok = _copy_to_clipboard(msg.text)
        try:
            if ok:
                short = msg.text.strip().splitlines()[0][:50]
                self.app.notify(f"скопировано: {short}",
                                severity="information", timeout=1.5)
            else:
                self.app.notify("не удалось скопировать",
                                severity="error", timeout=2)
        except Exception:
            pass

    def on_key(self, event) -> None:
        if event.key == "escape":
            self.dismiss(None)


# ══════════════════════════════════════════════════════════════════
#  БЛОК 4. ВИДЖЕТЫ ТОПБАРА
# ══════════════════════════════════════════════════════════════════

class MenuTriangle(Static):
    class Pressed(Message):
        pass

    def on_mount(self) -> None:
        self.update("▲")

    def on_click(self) -> None:
        self.post_message(self.Pressed())


class QuickButton(Static):
    class Pressed(Message):
        def __init__(self, command: str) -> None:
            super().__init__()
            self.command = command

    def __init__(self, label: str, command: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self._label = label
        self._command = command

    def on_mount(self) -> None:
        self.update(f"[ {self._label} ]")

    def on_click(self) -> None:
        self.post_message(self.Pressed(self._command))


class PasteButton(Static):
    """Кнопка вставки из буфера обмена."""
    class Pressed(Message):
        pass

    def on_mount(self) -> None:
        self.update("[ + ]")

    def on_click(self) -> None:
        self.post_message(self.Pressed())


# ──────────────────────────────────────────────────────────────────
#  Анимированные виджеты шапки (только геометрические символы!)
# ──────────────────────────────────────────────────────────────────

class PacketCounter(Static):
    """Живой счётчик пакетов и pps — растёт и пульсирует."""
    def on_mount(self) -> None:
        self._total = random.randint(100000, 900000)
        self._pps   = random.randint(500, 2500)
        self._tick()
        self.set_interval(0.20, self._tick)

    def _tick(self) -> None:
        self._total += random.randint(80, 900)
        self._pps = max(50, min(9999, self._pps + random.randint(-400, 450)))
        try:
            self.update(
                f"[#8b1a1a]▸[/][#e94b4b][b]PKT[/b][/] "
                f"[#c93a3a]{self._total:>8}[/] "
                f"[#5a2a82]·[/] "
                f"[#a06cd5]{self._pps:>4}[/][#5a2a82]pps[/]"
            )
        except Exception:
            pass


class LoadBars(Static):
    """Анимированные полоски загрузки CPU / MEM / NET."""
    W = 5

    def on_mount(self) -> None:
        self._cpu = 25
        self._mem = 55
        self._net = 30
        self._tick()
        self.set_interval(0.15, self._tick)

    def _bar(self, v: int) -> str:
        f = max(0, min(self.W, int(self.W * v / 100)))
        return "■" * f + "□" * (self.W - f)

    def _tick(self) -> None:
        self._cpu = max(0, min(100, self._cpu + random.randint(-18, 22)))
        self._mem = max(0, min(100, self._mem + random.randint(-6, 9)))
        self._net = max(0, min(100, self._net + random.randint(-35, 40)))
        try:
            self.update(
                f"[#c93a3a]C[/][#8b1a1a]{self._bar(self._cpu)}[/]"
                f"[#2b0f3a]|[/]"
                f"[#c93a3a]M[/][#8b1a1a]{self._bar(self._mem)}[/]"
                f"[#2b0f3a]|[/]"
                f"[#c93a3a]N[/][#8b1a1a]{self._bar(self._net)}[/]"
            )
        except Exception:
            pass


class HexTicker(Static):
    """Бегущие HEX-значения (как дамп памяти) + шум битов."""
    def on_mount(self) -> None:
        self._vals = [random.randint(0, 0xFFFF) for _ in range(4)]
        self._tick()
        self.set_interval(0.11, self._tick)

    def _tick(self) -> None:
        for i in range(len(self._vals)):
            if random.random() < 0.45:
                self._vals[i] = (self._vals[i] +
                                 random.randint(1, 0xFFF)) & 0xFFFF
        body = " ".join(f"{v:04X}" for v in self._vals)
        trail = "".join(random.choice("01") for _ in range(8))
        try:
            self.update(
                f"[#5a2a82]0x[/][#8b1a1a]{body}[/] "
                f"[#2b0f3a]{trail}[/]"
            )
        except Exception:
            pass


class ThreatLevel(Static):
    """Мигающий уровень угрозы."""
    LEVELS = [
        ("LOW ", VIOLET),
        ("MED ", VIOLET_LIGHT),
        ("HIGH", TEXT_RED),
        ("CRIT", NEON),
    ]

    def on_mount(self) -> None:
        self._phase = 0
        self._blink = False
        self._tick()
        self.set_interval(0.55, self._tick)

    def _tick(self) -> None:
        self._blink = not self._blink
        if self._blink:
            self._phase = (self._phase + 1) % len(self.LEVELS)
        label, color = self.LEVELS[self._phase]
        mark = "◆" if self._blink else "◇"
        try:
            self.update(
                f"[#8b1a1a]{mark}[/] [{color}][b]T:{label}[/][/]"
            )
        except Exception:
            pass


class SignalBars(Static):
    """Пульсирующий индикатор сигнала (5 делений)."""
    def on_mount(self) -> None:
        self._v = 3
        self._tick()
        self.set_interval(0.28, self._tick)

    def _tick(self) -> None:
        self._v = max(0, min(5,
                             self._v + random.choice([-1, 0, 0, 1, 1, 1])))
        bars = []
        for i in range(5):
            if i < self._v:
                bars.append("[#c93a3a]▮[/]")
            else:
                bars.append("[#2b0f3a]▯[/]")
        try:
            self.update("[#5a2a82]▸[/]" + "".join(bars))
        except Exception:
            pass


class KaliClock(Static):
    def on_mount(self) -> None:
        self._tick()
        self.set_interval(1.0, self._tick)

    def _tick(self) -> None:
        now = datetime.now()
        try:
            self.update(
                f"◆ {now.strftime('%H:%M:%S')} ▐ {now.strftime('%d.%m')}"
            )
        except Exception:
            pass


class WelcomePanel(Static):
    def on_mount(self) -> None:
        greeting = random.choice(GREETINGS)
        text = f"""{BANNER}

[#c93a3a][b]◆ A B A D O N   S O F T ◆[/b][/]

[#5a2a82]────────────────────────────────[/]

[#b794f4]{greeting}[/]

[#2b0f3a]введи[/] [#a06cd5][b]help[/b][/] [#2b0f3a]или[/] [#a06cd5][b]menu[/b][/] [#2b0f3a]— увижу, чем помочь[/]
[#2b0f3a]или нажми[/] [#c93a3a][b]▲[/b][/] [#2b0f3a]сверху слева — то же самое[/]

[#5a2a82]напиши[/] [#c93a3a][b]main[/b][/] [#5a2a82]в любой момент — верну сюда[/]

[#5a2a82]────────────────────────────────[/]
[#c93a3a][b]◆ горячие клавиши:[/b][/]
  [#a06cd5][b]Shift + мышь [/b][/] [dim]— выделить текст[/]
  [#a06cd5][b]Ctrl+C[/b][/] [dim]— копировать выделенное[/]
  [#a06cd5][b]Ctrl+V[/b][/] [dim]— вставить в поле ввода[/]
  [#a06cd5][b]Ctrl+A[/b][/] [dim]— удалить всю строку ввода[/]
"""
        self.update(text)


# ══════════════════════════════════════════════════════════════════
#  БЛОК 5. ПРИЛОЖЕНИЕ
# ══════════════════════════════════════════════════════════════════

class AbadonApp(App):
    """
    Настройки для копирования/вставки:

      * ENABLE_MOUSE = False — Textual НЕ захватывает мышь.
      * Ctrl+V / клик по [+] — вставка из буфера.
      * Ctrl+A / Ctrl+U — очистить строку ввода.
      * Ctrl+W — удалить слово. Ctrl+K — до конца.
      * Выход — Ctrl+Q.
    """

    ENABLE_MOUSE = False
    ENABLE_COMMAND_PALETTE = False

    CSS = f"""
    Screen {{ background: {BG}; color: {TEXT_VIOLET}; }}

    #topbar {{
        dock: top; height: 3;
        background: {VIOLET_DARK}; border-bottom: heavy {BLOOD};
    }}
    #menu-triangle {{
        width: auto; height: 100%; padding: 0 2;
        color: {NEON}; text-style: bold; background: {DARK_RED};
        content-align: center middle;
    }}
    #menu-triangle:hover {{ background: {BLOOD}; color: {TEXT_RED}; }}
    .quick-btn {{
        width: auto; height: 100%; padding: 0 1;
        color: {VIOLET_LIGHT}; text-style: bold;
        content-align: center middle;
    }}
    .quick-btn:hover {{ background: {BLOOD}; color: {TEXT_RED}; }}

    #pkt-counter {{
        width: auto; height: 100%; padding: 0 1;
        content-align: center middle;
    }}
    #load-bars {{
        width: auto; height: 100%; padding: 0 1;
        content-align: center middle;
    }}
    #hex-ticker {{
        width: 1fr; height: 100%; padding: 0 2;
        content-align: left middle;
    }}
    #threat {{
        width: auto; height: 100%; padding: 0 1;
        content-align: center middle;
    }}
    #signal {{
        width: auto; height: 100%; padding: 0 1;
        content-align: center middle;
    }}
    #kali-clock {{
        width: auto; height: 100%; padding: 0 2;
        content-align: right middle; color: {TEXT_RED}; text-style: bold;
    }}

    #chat-scroll {{
        border: round {VIOLET}; background: {BG};
        padding: 0 1; height: 1fr;
    }}
    #welcome {{
        height: 100%; content-align: center middle;
        color: {TEXT_RED}; text-align: center;
    }}
    RichLog {{
        background: {BG}; color: {TEXT_VIOLET};
        scrollbar-color: {VIOLET}; scrollbar-background: {BG};
    }}

    /* ─── Строка ввода в стиле Kali Linux ────────────────────── */
    #input-area {{
        height: 4;
        background: {VIOLET_DARK};
        border: round {BLOOD};
        padding: 0 1;
    }}
    #kali-banner-row {{
        height: 1;
        background: {VIOLET_DARK};
    }}
    #kali-banner {{
        width: 1fr;
        height: 1;
        color: {VIOLET_LIGHT};
        content-align: left middle;
    }}
    #kali-hint {{
        width: auto;
        height: 1;
        padding: 0 1;
        color: {VIOLET};
        content-align: right middle;
    }}
    #input-row {{
        height: 1;
        background: {VIOLET_DARK};
    }}
    #prompt {{
        width: auto;
        height: 1;
        padding: 0 1 0 0;
        color: {TEXT_RED};
        text-style: bold;
        content-align: left middle;
    }}
    #cmd-input {{
        background: {VIOLET_DARK};
        color: {TEXT_VIOLET};
        border: none;
        height: 1;
        padding: 0 0 0 0;
    }}
    #cmd-input:focus {{
        background: {VIOLET_DARK};
    }}
    #paste-btn {{
        width: 5; height: 1;
        padding: 0 1;
        color: {NEON}; text-style: bold; background: {DARK_RED};
        content-align: center middle;
    }}
    #paste-btn:hover {{ background: {BLOOD}; color: #ffffff; }}
    """

    BINDINGS = [
        Binding("ctrl+q", "quit", "Выход", priority=True),
        Binding("ctrl+l", "clear_chat", "Очистить"),
        Binding("ctrl+m", "open_menu", "Меню"),
        Binding("ctrl+y", "copy_log", "Копия лога"),
        Binding("ctrl+v", "paste_from_clipboard", "Вставить", priority=True),
    ]

    def __init__(self):
        super().__init__()
        self._welcome_shown = True
        self._running_module = None
        self._log_queue = queue.Queue()
        self._stop_flag = _StopFlag()
        self._menu_map = self._build_menu_map()

    def _build_menu_map(self):
        m = {}
        for i, mod in enumerate(MODULES, 1):
            m[str(i)] = mod["name"]
            m[mod["name"]] = mod["name"]
            for al in mod.get("aliases", []) or []:
                m[str(al).lower()] = mod["name"]
        return m

    def compose(self) -> ComposeResult:
        with Horizontal(id="topbar"):
            yield MenuTriangle(id="menu-triangle")
            for m in MODULES[:4]:
                yield QuickButton(m["name"], m["name"],
                                  id=f"qb-{m['name']}", classes="quick-btn")
            yield PacketCounter(id="pkt-counter")
            yield LoadBars(id="load-bars")
            yield HexTicker(id="hex-ticker")
            yield ThreatLevel(id="threat")
            yield SignalBars(id="signal")
            yield KaliClock(id="kali-clock")

        with VerticalScroll(id="chat-scroll"):
            yield WelcomePanel(id="welcome")
            yield RichLog(id="chat-log", markup=True, wrap=True, highlight=True)

        # ─── Kali-style prompt ──────────────────────────────────
        with Container(id="input-area"):
            with Horizontal(id="kali-banner-row"):
                yield Static(
                    "[#5a2a82]┌──[/]"
                    "[#e94b4b]([/]"
                    "[#c93a3a][b]abadon[/b][/]"
                    "[#a06cd5]㉿[/]"
                    "[#c93a3a][b]soft[/b][/]"
                    "[#e94b4b])[/]"
                    "[#5a2a82]-[[/]"
                    "[#b794f4]~[/]"
                    "[#5a2a82]][/]",
                    id="kali-banner"
                )
                yield Static(
                    "[#2b0f3a]ctrl+v[/] [#5a2a82]paste[/]  "
                    "[#2b0f3a]ctrl+a[/] [#5a2a82]clear[/]",
                    id="kali-hint"
                )
            with Horizontal(id="input-row"):
                yield Static(
                    "[#5a2a82]└─[/][#c93a3a][b]$[/b][/] ",
                    id="prompt"
                )
                yield AbadonInput(
                    placeholder="введи команду… (help / menu / main)",
                    id="cmd-input"
                )
                yield PasteButton(id="paste-btn")

    def on_mount(self) -> None:
        try:
            self.query_one("#chat-log", RichLog).display = False
        except Exception:
            pass
        try:
            self.query_one("#cmd-input", AbadonInput).focus()
        except Exception:
            pass
        self.set_interval(0.05, self._flush_queue)

    # ═══ ВСТАВКА ══════════════════════════════════════════════════
    def _do_paste(self) -> None:
        text = _get_from_clipboard()
        if not text:
            try:
                self.notify("буфер пуст",
                            severity="warning", timeout=1.5)
            except Exception:
                pass
            return
        try:
            inp = self.query_one("#cmd-input", AbadonInput)
            current = inp.value or ""
            clean = text.replace("\r", "").replace("\n", " ").strip()
            inp.value = current + clean
            inp.focus()
            try:
                inp.cursor_position = len(inp.value)
            except Exception:
                pass
        except Exception as e:
            try:
                self.notify(f"ошибка вставки: {e}",
                            severity="error", timeout=2)
            except Exception:
                pass

    def action_paste_from_clipboard(self) -> None:
        self._do_paste()

    def on_paste_button_pressed(self, event: PasteButton.Pressed) -> None:
        self._do_paste()

    # ═══ ОЧЕРЕДЬ → ЧАТ ════════════════════════════════════════════
    def _flush_queue(self) -> None:
        try:
            log = self.query_one("#chat-log", RichLog)
        except Exception:
            return
        count = 0
        while count < 80:
            try:
                text = self._log_queue.get_nowait()
            except queue.Empty:
                break

            if text.startswith("@@COPY_SCREEN@@"):
                try:
                    payload = json.loads(text[len("@@COPY_SCREEN@@"):])
                    title = payload.get("title", "Копирование")
                    lines = payload.get("lines", [])
                    if isinstance(lines, list) and lines:
                        self.push_screen(CopyScreen(title, lines))
                except Exception:
                    pass
                count += 1
                continue

            try:
                log.write(text)
            except Exception:
                pass
            count += 1

    def emit(self, text: str) -> None:
        try:
            self.query_one("#chat-log", RichLog).write(text)
        except Exception:
            pass

    def emit_threadsafe(self, text: str) -> None:
        try:
            self._log_queue.put(text)
        except Exception:
            pass

    # ═══ АССИСТЕНТ-ГОЛОС ══════════════════════════════════════════
    def _say(self, text: str) -> None:
        """Реплика ассистента."""
        self.emit(f"[#c93a3a][b]◆ Abadon:[/b][/] [#b794f4]{text}[/]")

    def _say_threadsafe(self, text: str) -> None:
        self.emit_threadsafe(
            f"[#c93a3a][b]◆ Abadon:[/b][/] [#b794f4]{text}[/]"
        )

    # ═══ ПЕРЕХОД В ЧАТ ════════════════════════════════════════════
    def _switch_to_chat(self) -> None:
        if not self._welcome_shown:
            return
        self._welcome_shown = False
        try:
            self.query_one("#welcome").display = False
        except Exception:
            pass
        try:
            log = self.query_one("#chat-log", RichLog)
            log.display = True
            log.write(f"[#2b0f3a]┌─[dim]{datetime.now().strftime('%H:%M:%S')}[/dim]"
                      + "─" * 30 + "[/]")
            log.write(f"[#c93a3a][b]◆ Abadon:[/b][/] [#a06cd5]"
                      f"{random.choice(GREETINGS)}. Слушаю.[/]")
            log.write("[#2b0f3a]└" + "─" * 40 + "[/]")
        except Exception:
            pass

    # ═══ ГЛАВНОЕ МЕНЮ (main) ══════════════════════════════════════
    def _action_main(self) -> None:
        """Вернуться в главное меню (перезапустить welcome)."""
        self._welcome_shown = True
        try:
            log = self.query_one("#chat-log", RichLog)
            log.display = False
            log.clear()
        except Exception:
            pass
        try:
            self.query_one("#welcome").display = True
        except Exception:
            pass
        try:
            inp = self.query_one("#cmd-input", AbadonInput)
            inp.value = ""
            inp.focus()
        except Exception:
            pass

    # ═══ МЕНЮ-ДИАЛОГ ══════════════════════════════════════════════
    def _show_menu_dialogue(self) -> None:
        """Показать меню модулей как диалог ассистента."""
        self._switch_to_chat()

        self.emit(
            "[#c93a3a][b]◆ Abadon:[/b][/] "
            "[#b794f4]Вот что я умею. Выбирай — номером или именем.[/]"
        )
        self.emit("")

        if not MODULES:
            self.emit("  [#5a2a82]— модули не найдены (папка modules/ пуста)[/]")
        else:
            for i, m in enumerate(MODULES, 1):
                al = m.get("aliases") or []
                alias_tail = ""
                if al:
                    alias_tail = ("  [#2b0f3a](он же: "
                                  + ", ".join(al) + ")[/]")
                self.emit(
                    f"  [#c93a3a][b]{i:>2}.[/b][/]  "
                    f"[#a06cd5][b]{m['name']:<10}[/b][/] "
                    f"[#5a2a82]—[/] [#b794f4]{m['desc']}[/]"
                    f"{alias_tail}"
                )

        self.emit("")
        self.emit("  [#5a2a82]└─[/] [#b794f4]можно ответить:[/] "
                  "[#c93a3a][b]1[/b][/] [#5a2a82]·[/] "
                  "[#c93a3a][b]wifi[/b][/] [#5a2a82]·[/] "
                  "[#c93a3a][b]help[/b][/] [#5a2a82]для подробностей[/]")
        self.emit("  [#5a2a82]   [/] [#b794f4]вернуться в главное меню:[/] "
                  "[#c93a3a][b]main[/b][/]")

    def on_menu_triangle_pressed(self, event: MenuTriangle.Pressed) -> None:
        self._show_menu_dialogue()

    def on_quick_button_pressed(self, event: QuickButton.Pressed) -> None:
        try:
            inp = self.query_one("#cmd-input", AbadonInput)
            inp.value = f"{event.command} "
            inp.focus()
        except Exception:
            pass

    def action_open_menu(self) -> None:
        self._show_menu_dialogue()

    def action_copy_log(self) -> None:
        self._say("Подсказка: Ctrl+V — вставить, Ctrl+A — очистить строку, "
                  "Ctrl+L — очистить консоль, Ctrl+Q — выход")

    # ═══ ОТПРАВКА КОМАНДЫ ════════════════════════════════════════
    def on_input_submitted(self, event: Input.Submitted) -> None:
        cmd = event.value.strip()
        if not cmd:
            return

        event.input.value = ""
        self._switch_to_chat()

        self.emit("[#5a2a82]┌─ [dim]ты[/dim] ─────────────────────────────[/]")
        self.emit(f"[#b794f4][b]◆[/b] {cmd}[/]")

        self._dispatch(cmd)
        self.emit("[#2b0f3a]─────────────────────────────────────────[/]")

    def _dispatch(self, raw: str) -> None:
        parts = raw.split(maxsplit=1)
        cmd  = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        if self._running_module is not None:
            if cmd == "stop" or args.strip().lower() == "stop":
                self._stop_flag.request()
                self._say("Понял, останавливаю…")
                return
            self._say(
                f"Секунду — сейчас выполняется [b]{self._running_module}[/b]. "
                f"Напиши [b]stop[/b], если надо прервать."
            )
            return

        # ── main / menu / home ────────────────────────────────────
        if cmd in ("main", "home"):
            self._action_main()
            return

        if cmd in ("menu", "m"):
            self._show_menu_dialogue()
            return

        # ── выбор номером / алиасом из меню ───────────────────────
        if cmd in self._menu_map:
            cmd = self._menu_map[cmd]

        if cmd in ("help", "?", "h"):
            self._say("Держи список.")
            self.emit(help_text())
            return

        if cmd in ("clear", "cls"):
            try:
                self.query_one("#chat-log", RichLog).clear()
            except Exception:
                pass
            self._say("Консоль очищена")
            return

        if cmd in ("stop",):
            self._say("Сейчас нечего останавливать")
            return

        if cmd in ("exit", "quit", "q"):
            self._say("Отключаюсь. До связи")
            self.exit()
            return

        meta = get_module(cmd)
        if not meta:
            self._say(
                f"Не знаю такой команды: [b]{raw}[/b]. "
                f"Скажи [b]menu[/b] — покажу список"
            )
            return

        self._running_module = cmd
        self._stop_flag.clear()
        self._say(
            f"{random.choice(ASSISTANT_ACK)} — запускаю "
            f"[b]{meta['title']}[/b]…"
        )

        invoked_as = cmd
        stop_flag = self._stop_flag

        def worker():
            try:
                try:
                    meta["module"].run(args, self.emit_threadsafe,
                                       invoked_as=invoked_as,
                                       should_stop=stop_flag)
                except TypeError:
                    try:
                        meta["module"].run(args, self.emit_threadsafe,
                                           invoked_as=invoked_as)
                    except TypeError:
                        meta["module"].run(args, self.emit_threadsafe)
            except Exception as e:
                self._say_threadsafe(
                    f"Ошибка в модуле [b]{cmd}[/b]: {e}"
                )
            finally:
                self._running_module = None
                self._say_threadsafe(
                    f"{random.choice(ASSISTANT_DONE)} — "
                    f"[b]{cmd}[/b] отработал. "
                    f"[dim](menu — ещё что-нибудь)[/]"
                )

        threading.Thread(target=worker, daemon=True).start()

    def action_clear_chat(self) -> None:
        try:
            self.query_one("#chat-log", RichLog).clear()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════
#  БЛОК 6. ЗАПУСК
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    try:
        AbadonApp().run()
    except Exception:
        import traceback
        traceback.print_exc()
        input("\n[!] Enter - чтобы закрыть...")