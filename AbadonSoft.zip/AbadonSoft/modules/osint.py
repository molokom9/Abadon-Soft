"""
Abadon Soft — OSINT / разведка (аналог theHarvester / recon-ng).

Команды:
    osint <IP или домен>     — полная разведка
    osint ip <IP>            — геолокация IP
    osint dns <домен>        — DNS записи
    osint headers <URL>      — HTTP заголовки
    osint trace <хост>       — traceroute
    osint whois <домен>      — WHOIS (через nslookup)
"""

import os
import sys
import json
import time
import socket
import subprocess
import threading

NAME    = "osint"
TITLE   = "OSINT & Recon"
DESC    = "IP-геолокация, DNS, HTTP-заголовки, трассировка"
USAGE   = "osint <ip/domain> [ip|dns|headers|trace|whois]"
ALIASES = ["recon", "info", "lookup"]

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# ─── Утилиты ─────────────────────────────────────────────────────

def _req(url: str, timeout: float = 6.0) -> dict | None:
    """Простой HTTP GET через сокеты (не нужен requests при базовой работе)."""
    try:
        import urllib.request
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _run(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout,
                           creationflags=_NO_WINDOW)
        raw = r.stdout or b""
        for enc in ("utf-8", "cp866", "cp1251"):
            try:
                return raw.decode(enc)
            except Exception:
                pass
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return ""


def _resolve_all(host: str) -> tuple:
    """(ip, host). Резолвим хост."""
    try:
        ip   = socket.gethostbyname(host)
        try:
            rhost = socket.gethostbyaddr(ip)[0]
        except Exception:
            rhost = ""
        return ip, rhost
    except Exception:
        return "", ""


def _is_ip(s: str) -> bool:
    parts = s.split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


# ─── Геолокация IP ───────────────────────────────────────────────

def _cmd_ip(emit, target: str):
    emit(f"[#a06cd5]◆ цель:[/] [b]{target}[/]")

    if not _is_ip(target):
        emit("[#5a2a82]◆ резолвю…[/]")
        ip, rhost = _resolve_all(target)
        if not ip:
            emit(f"[#c93a3a]◆ не могу резолвить: {target}[/]")
            return
        emit(f"[#a06cd5]◆ IP:[/] [b]{ip}[/]")
        target = ip

    emit("[#5a2a82]◆ запрашиваю геоданные…[/]")
    data = _req(f"http://ip-api.com/json/{target}?fields=status,message,"
                f"country,countryCode,region,regionName,city,zip,lat,lon,"
                f"isp,org,as,reverse,mobile,proxy,hosting,query")

    if not data or data.get("status") != "success":
        emit(f"[#c93a3a]◆ не удалось получить геоданные[/]")
        return

    emit("")
    emit(f"[#c93a3a][b]◆ ГЕОЛОКАЦИЯ — {target}[/b][/]")
    emit("")

    fields = [
        ("IP",          data.get("query", "—")),
        ("Страна",      f"{data.get('country','—')} [{data.get('countryCode','')}]"),
        ("Регион",      data.get("regionName", "—")),
        ("Город",       data.get("city", "—")),
        ("ZIP",         data.get("zip", "—")),
        ("Координаты",  f"{data.get('lat','?')}, {data.get('lon','?')}"),
        ("ISP",         data.get("isp", "—")),
        ("Организация", data.get("org", "—")),
        ("AS",          data.get("as", "—")),
        ("PTR (rDNS)",  data.get("reverse", "—")),
        ("Мобильный",   "да" if data.get("mobile") else "нет"),
        ("Прокси/VPN",  "да" if data.get("proxy") else "нет"),
        ("Хостинг",     "да" if data.get("hosting") else "нет"),
    ]

    result_lines = ["=" * 60, f"  OSINT — IP: {target}", "=" * 60, ""]
    for label, value in fields:
        emit(f"  [#a06cd5]{label:<14}[/] [b]{value}[/]")
        result_lines.append(f"  {label:<14} {value}")
    result_lines += ["", "=" * 60]

    emit("")
    # Maps ссылка
    lat, lon = data.get("lat", ""), data.get("lon", "")
    if lat and lon:
        emit(f"[#5a2a82]  ◆ карта: https://maps.google.com/?q={lat},{lon}[/]")
        result_lines.append(f"  Карта: https://maps.google.com/?q={lat},{lon}")

    try:
        emit("@@COPY_SCREEN@@" + json.dumps({
            "title": f"osint ip {target}",
            "lines": result_lines,
        }, ensure_ascii=False))
    except Exception:
        pass


# ─── DNS записи ──────────────────────────────────────────────────

def _nslookup(host: str, rtype: str = "A") -> str:
    return _run(["nslookup", f"-type={rtype}", host], timeout=8)


def _cmd_dns(emit, domain: str):
    emit(f"[#a06cd5]◆ домен:[/] [b]{domain}[/]")
    emit("[#5a2a82]◆ получаю DNS записи…[/]")
    emit("")

    result_lines = ["=" * 60, f"  DNS — {domain}", "=" * 60, ""]

    for rtype in ("A", "AAAA", "MX", "NS", "TXT", "CNAME"):
        out = _nslookup(domain, rtype)
        lines = []
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            skip_keywords = (
                "Server:", "Address:", "Non-authoritative",
                "DNS request", "*** Can't", "Default Server"
            )
            if any(k in line for k in skip_keywords):
                continue
            if "=" in line or "text =" in line or "mail exchanger" in line \
               or "nameserver" in line or "canonical" in line or "has AAAA" in line:
                lines.append(line)

        if lines:
            emit(f"  [#e94b4b][b]{rtype:<6}[/b][/] [#5a2a82]{'─'*40}[/]")
            result_lines.append(f"  [{rtype}]")
            for l in lines:
                emit(f"         [#b794f4]{l}[/]")
                result_lines.append(f"    {l}")
            result_lines.append("")

    # Также обычный резолв
    try:
        ip = socket.gethostbyname(domain)
        emit(f"  [#e94b4b][b]A (socket)[/b][/]  [b]{ip}[/]")
        try:
            rdns = socket.gethostbyaddr(ip)[0]
            emit(f"  [#e94b4b][b]PTR[/b][/]        [b]{rdns}[/]")
            result_lines.append(f"  PTR    {rdns}")
        except Exception:
            pass
        result_lines.append(f"  A      {ip}")
    except Exception:
        pass

    result_lines.append("=" * 60)
    emit("")

    try:
        emit("@@COPY_SCREEN@@" + json.dumps({
            "title": f"osint dns {domain}",
            "lines": result_lines,
        }, ensure_ascii=False))
    except Exception:
        pass


# ─── HTTP заголовки ──────────────────────────────────────────────

def _cmd_headers(emit, url: str):
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    emit(f"[#a06cd5]◆ URL:[/] [b]{url}[/]")
    emit("[#5a2a82]◆ запрашиваю заголовки…[/]")

    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "AbadonSoft/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            code    = resp.status
            headers = dict(resp.headers)
    except Exception as e:
        emit(f"[#c93a3a]◆ ошибка: {e}[/]")
        return

    emit("")
    emit(f"[#c93a3a][b]◆ HTTP ЗАГОЛОВКИ — {url}[/b][/]")
    emit(f"  [#e94b4b][b]Статус:[/b][/] [b]{code}[/]")
    emit("")

    result_lines = ["=" * 60, f"  HTTP Headers — {url}", f"  Статус: {code}", "=" * 60, ""]

    interesting = {
        "server", "x-powered-by", "x-aspnet-version", "x-generator",
        "content-type", "content-security-policy", "x-frame-options",
        "strict-transport-security", "x-xss-protection", "set-cookie",
        "access-control-allow-origin", "location", "via", "x-forwarded-for",
    }

    for k, v in sorted(headers.items()):
        is_interesting = k.lower() in interesting
        if is_interesting:
            emit(f"  [#e94b4b][b]{k}:[/b][/] [b]{v}[/]")
        else:
            emit(f"  [#a06cd5]{k}:[/] [dim]{v}[/]")
        result_lines.append(f"  {k}: {v}")

    result_lines.append("=" * 60)
    emit("")

    # Подсказки безопасности
    h_lower = {k.lower(): v for k, v in headers.items()}
    issues  = []
    if "x-powered-by" in h_lower:
        issues.append(f"⚠ X-Powered-By раскрывает технологию: {h_lower['x-powered-by']}")
    if "server" in h_lower:
        issues.append(f"⚠ Server раскрывает версию: {h_lower['server']}")
    if "x-frame-options" not in h_lower:
        issues.append("⚠ X-Frame-Options отсутствует (возможен Clickjacking)")
    if "strict-transport-security" not in h_lower:
        issues.append("⚠ HSTS отсутствует")
    if "content-security-policy" not in h_lower:
        issues.append("⚠ CSP заголовок отсутствует")

    if issues:
        emit(f"[#c93a3a][b]◆ ЗАМЕЧАНИЯ БЕЗОПАСНОСТИ:[/b][/]")
        for iss in issues:
            emit(f"  [#e94b4b]{iss}[/]")
        result_lines += ["", "Замечания:"] + [f"  {i}" for i in issues]

    try:
        emit("@@COPY_SCREEN@@" + json.dumps({
            "title": f"osint headers {url}",
            "lines": result_lines,
        }, ensure_ascii=False))
    except Exception:
        pass


# ─── Traceroute ──────────────────────────────────────────────────

def _cmd_trace(emit, target: str):
    emit(f"[#a06cd5]◆ цель:[/] [b]{target}[/]")
    emit("[#e94b4b][b]◆ tracert…[/b][/]")
    emit("")

    cmd = ["tracert", "-d", "-w", "1000", "-h", "20", target] \
          if sys.platform == "win32" else \
          ["traceroute", "-n", "-m", "20", target]

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                creationflags=_NO_WINDOW)
        for line_b in proc.stdout:
            for enc in ("utf-8", "cp866", "cp1251"):
                try:
                    line = line_b.decode(enc).rstrip()
                    break
                except Exception:
                    line = line_b.decode("utf-8", errors="replace").rstrip()
            if line.strip():
                emit(f"  [#b794f4]{line}[/]")
        proc.wait(timeout=60)
    except Exception as e:
        emit(f"[#c93a3a]◆ ошибка: {e}[/]")


# ─── Полная разведка ─────────────────────────────────────────────

def _cmd_full(emit, target: str, should_stop):
    emit(f"[#c93a3a][b]◆ ПОЛНАЯ РАЗВЕДКА — {target}[/b][/]")
    emit("")

    # 1. Резолв
    emit("[#5a2a82]◆ [1/3] Резолвлю и геолоцирую…[/]")
    _cmd_ip(emit, target)
    emit("")
    if should_stop(): return

    # 2. DNS
    domain = target
    if _is_ip(target):
        try:
            domain = socket.gethostbyaddr(target)[0]
        except Exception:
            domain = target

    if not _is_ip(domain):
        emit("[#5a2a82]◆ [2/3] DNS записи…[/]")
        _cmd_dns(emit, domain)
        emit("")
        if should_stop(): return

    # 3. HTTP заголовки
    emit("[#5a2a82]◆ [3/3] HTTP заголовки…[/]")
    _cmd_headers(emit, target)


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ OSINT / RECON[/b][/]")
        emit("")
        emit("  [b]osint <target>[/b]            — полная разведка")
        emit("  [b]osint ip <IP>[/b]             — геолокация IP")
        emit("  [b]osint dns <domain>[/b]        — DNS записи")
        emit("  [b]osint headers <URL>[/b]       — HTTP заголовки")
        emit("  [b]osint trace <host>[/b]        — traceroute")
        emit("")
        emit("[#5a2a82]  пример: osint 8.8.8.8[/]")
        emit("[#5a2a82]  пример: osint google.com[/]")
        return

    parts = args.split(maxsplit=1)
    sub   = parts[0].lower()
    rest  = parts[1].strip() if len(parts) > 1 else ""

    emit("")

    if sub in ("ip", "geo", "g"):
        if not rest:
            emit("[#c93a3a]◆ укажи IP: osint ip <IP>[/]"); return
        _cmd_ip(emit, rest)
    elif sub in ("dns", "d"):
        if not rest:
            emit("[#c93a3a]◆ укажи домен: osint dns <domain>[/]"); return
        _cmd_dns(emit, rest)
    elif sub in ("headers", "head", "http", "h"):
        if not rest:
            emit("[#c93a3a]◆ укажи URL: osint headers <url>[/]"); return
        _cmd_headers(emit, rest)
    elif sub in ("trace", "tracert", "t"):
        if not rest:
            emit("[#c93a3a]◆ укажи хост: osint trace <host>[/]"); return
        _cmd_trace(emit, rest)
    else:
        # sub — это сам таргет, full recon
        _cmd_full(emit, sub, should_stop)
