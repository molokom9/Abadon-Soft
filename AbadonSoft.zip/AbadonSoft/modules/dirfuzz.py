"""
Abadon Soft — веб-фаззер директорий (аналог gobuster / dirb).
Ищет скрытые файлы и директории на веб-серверах.

Команды:
    dirfuzz <URL>                   — встроенный словарь
    dirfuzz <URL> <словарь.txt>     — свой словарь
    dirfuzz <URL> fast              — быстрый режим (меньше слов)
    dirfuzz <URL> ext php,html,js   — с расширениями файлов
"""

import os
import sys
import time
import threading
import queue
import json

NAME    = "dirfuzz"
TITLE   = "Dir Fuzzer"
DESC    = "Поиск скрытых директорий на веб-сервере (gobuster аналог)"
USAGE   = "dirfuzz <URL> [fast|<словарь>] [ext php,html]"
ALIASES = ["df", "dirscan", "dirbust", "dirs"]

MAX_THREADS = 20
TIMEOUT     = 6.0

# --- Встроенный словарь ---

WORDLIST_FAST = [
    "admin", "login", "wp-admin", "dashboard", "panel", "cpanel",
    "phpmyadmin", "pma", "phpinfo", "api", "v1", "v2", "swagger",
    "console", "manager", "management", "config", "conf",
    "backup", "bak", ".git", ".env", "robots.txt", "sitemap.xml",
    "wp-login.php", "xmlrpc.php", "readme.html", "CHANGELOG.txt",
    "LICENSE.txt", "install", "setup", "test", "demo", "staging",
    "dev", "development", "beta", "old", "temp", "tmp", ".htaccess",
    "web.config", "composer.json", "package.json", "requirements.txt",
    "Dockerfile", ".dockerignore", "Makefile",
]

WORDLIST_FULL = WORDLIST_FAST + [
    "about", "about-us", "account", "accounts", "admin2", "administrator",
    "api-docs", "app", "application", "archive", "assets", "auth",
    "authentication", "blog", "cache", "cgi-bin", "cgi", "checkout",
    "client", "clients", "cms", "contact", "content", "control",
    "core", "css", "data", "database", "db", "debug", "delete",
    "docs", "documentation", "download", "downloads", "email", "error",
    "errors", "files", "forum", "forums", "gateway", "graphql",
    "health", "help", "home", "html", "images", "img", "includes",
    "info", "internal", "js", "json", "lib", "libraries", "library",
    "license", "log", "logs", "media", "mobile", "modules", "monitor",
    "new", "news", "old_admin", "option", "options", "order",
    "page", "pages", "payment", "portal", "private", "product",
    "products", "profile", "public", "register", "registration",
    "report", "reports", "reset", "resources", "rss.xml", "script",
    "scripts", "search", "secure", "security", "server", "service",
    "services", "settings", "shop", "site", "sql", "src", "static",
    "stats", "status", "storage", "store", "system", "templates",
    "token", "tools", "update", "upload", "uploads", "user",
    "users", "vendor", "views", "web", "webmail", "webmaster",
    "wordpress", "wp", "wp-content", "wp-includes", "www",
    "xml", "xmlrpc", "xss", ".svn", ".htpasswd", ".bash_history",
    "error.log", "access.log", "server.log", "debug.log",
    "database.yml", "config.php", "config.yml", "settings.py",
    "local_settings.py", ".travis.yml", ".circleci",
]

# --- Утилиты ---

def _req_head(url: str, timeout: float = 6.0) -> tuple:
    """Возвращает (status, size, type, err). Без внешних зависимостей."""
    try:
        import urllib.request
        import urllib.error
        req = urllib.request.Request(
            url,
            method="HEAD",
            headers={
                "User-Agent": "Mozilla/5.0 AbadonSoft/1.0",
                "Accept": "*/*",
            }
        )
        opener = urllib.request.build_opener(
            urllib.request.HTTPRedirectHandler()
        )
        try:
            with opener.open(req, timeout=timeout) as resp:
                size  = resp.headers.get("Content-Length", "-")
                stype = resp.headers.get("Content-Type", "")
                return resp.status, size, stype[:30], ""
        except urllib.error.HTTPError as e:
            return e.code, "-", "", ""
    except Exception as e:
        return 0, "-", "", str(e)[:40]


def _load_wordlist(path: str) -> list:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip()]
    except Exception:
        return []


def _color_for_code(code: int) -> str:
    if code == 200:    return "#e94b4b"
    if code in (301, 302, 303, 307, 308): return "#a06cd5"
    if code == 403:    return "#c93a3a"
    if code == 401:    return "#b794f4"
    if code == 500:    return "#c93a3a"
    return ""


# --- Основной фаззер ---

def _fuzz(emit, base_url: str, words: list, extensions: list, should_stop):
    base_url = base_url.rstrip("/")
    found    = []
    lock     = threading.Lock()
    total    = [0]
    done     = [0]

    targets = []
    for w in words:
        targets.append(f"{base_url}/{w}")
        for ext in extensions:
            targets.append(f"{base_url}/{w}.{ext}")
    total[0] = len(targets)

    q = queue.Queue()
    for t in targets:
        q.put(t)

    def worker():
        while not should_stop():
            try:
                url = q.get_nowait()
            except queue.Empty:
                break

            code, size, ctype, err = _req_head(url)

            with lock:
                done[0] += 1

            if code in (200, 204, 206, 301, 302, 303, 307, 308,
                        401, 403, 405, 500, 501):
                color = _color_for_code(code)
                path  = url[len(base_url):]
                tag   = ""
                if code == 200:    tag = "[b]* НАЙДЕНО[/b]"
                elif code == 403:  tag = "[b]* FORBIDDEN[/b]"
                elif code == 401:  tag = "[b]* AUTH REQUIRED[/b]"
                elif code in (301,302,307,308): tag = "[b]* REDIRECT[/b]"
                elif code == 500:  tag = "[b]* SERVER ERROR[/b]"

                with lock:
                    found.append({
                        "url": url, "code": code,
                        "size": size, "ctype": ctype,
                    })

                if color:
                    emit(f"  [bold {color}][{code}][/bold {color}]  "
                         f"[{color}]{path:<40}[/]  "
                         f"[dim]{size:>8}  {ctype:<25}[/]  "
                         f"[bold {color}]{tag}[/bold {color}]")

            q.task_done()

    threads_list = []
    for _ in range(MAX_THREADS):
        t = threading.Thread(target=worker, daemon=True)
        t.start()
        threads_list.append(t)

    last_rep = time.time()
    while any(t.is_alive() for t in threads_list):
        if should_stop():
            break
        now = time.time()
        if now - last_rep >= 3.0:
            with lock:
                d, f = done[0], len(found)
            pct = d / total[0] * 100 if total[0] else 100
            emit(f"[#5a2a82]  * прогресс: {d}/{total[0]} ({pct:.0f}%) - "
                 f"найдено: {f}[/]")
            last_rep = now
        time.sleep(0.2)

    for t in threads_list:
        t.join(timeout=1)

    return found


# --- Точка входа ---

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]* WEB DIRECTORY FUZZER[/b][/]")
        emit("")
        emit("  [b]dirfuzz <URL>[/b]                  - встроенный словарь")
        emit("  [b]dirfuzz <URL> fast[/b]             - быстрый режим")
        emit("  [b]dirfuzz <URL> <словарь.txt>[/b]    - свой словарь")
        emit("  [b]dirfuzz <URL> ext php,html[/b]     - с расширениями")
        emit("")
        emit("[#5a2a82]  пример: dirfuzz http://192.168.1.1[/]")
        emit("[#5a2a82]  пример: dirfuzz http://192.168.1.1 ext php,html,txt[/]")
        return

    parts   = args.split()
    url     = parts[0]
    mode    = "full"
    wordlist_path = ""
    extensions    = []

    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    i = 1
    while i < len(parts):
        p = parts[i]
        if p == "fast":
            mode = "fast"
        elif p == "ext" and i + 1 < len(parts):
            extensions = parts[i + 1].lower().split(",")
            i += 1
        elif os.path.isfile(p):
            wordlist_path = p
        i += 1

    if wordlist_path:
        words = _load_wordlist(wordlist_path)
        if not words:
            emit(f"[#c93a3a]* не могу прочитать: {wordlist_path}[/]")
            return
        src = f"файл ({len(words)} слов)"
    elif mode == "fast":
        words = WORDLIST_FAST[:]
        src   = f"встроенный быстрый ({len(words)} слов)"
    else:
        words = WORDLIST_FULL[:]
        src   = f"встроенный ({len(words)} слов)"

    total_urls = len(words) * (1 + len(extensions))

    emit("")
    emit(f"[#c93a3a][b]* WEB FUZZER - СТАРТ[/b][/]")
    emit(f"[#a06cd5]* цель:[/]      [b]{url}[/]")
    emit(f"[#a06cd5]* словарь:[/]   [b]{src}[/]")
    emit(f"[#a06cd5]* extensions:[/][b]{','.join(extensions) or 'нет'}[/]")
    emit(f"[#a06cd5]* запросов:[/]  [b]{total_urls}[/]  "
         f"[dim](потоков: {MAX_THREADS})[/]")
    emit("[#e94b4b][b]* сканирую...[/b][/]")
    emit("")
    emit(f"  [#5a2a82]{'КОД':<7} {'ПУТЬ':<42} {'РАЗМЕР':<10} {'ТИП'}[/]")
    emit(f"  [#2b0f3a]{'-'*7} {'-'*42} {'-'*10} {'-'*25}[/]")

    t_start = time.time()
    found   = _fuzz(emit, url, words, extensions, should_stop)
    elapsed = time.time() - t_start

    if should_stop():
        emit("[#c93a3a]* остановлено[/]")
        return

    emit("")
    if not found:
        emit("[#c93a3a]* ничего не найдено[/]")
    else:
        emit(f"[#c93a3a][b]* ИТОГО НАЙДЕНО: {len(found)}[/b][/]")
        for f in sorted(found, key=lambda x: x["code"]):
            emit(f"  [{f['code']}]  [b]{f['url']}[/b]")

        result_lines = ["=" * 70, f"  DIRFUZZ - {url}", "=" * 70, ""]
        for f in found:
            result_lines.append(f"  [{f['code']}]  {f['url']}")
        result_lines += ["", "=" * 70]

        try:
            emit("@@COPY_SCREEN@@" + json.dumps({
                "title": f"dirfuzz {url}",
                "lines": result_lines,
            }, ensure_ascii=False))
        except Exception:
            pass

    emit(f"[#5a2a82]* время: {elapsed:.1f}с - проверено: {total_urls}[/]")