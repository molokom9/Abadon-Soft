"""
Abadon Soft — сканер портов (аналог nmap).
Работает через socket, не требует внешних инструментов.

Команды:
    portscan <host>              — топ-100 портов
    portscan <host> top          — топ-100 портов (явно)
    portscan <host> full         — все 65535 (медленно)
    portscan <host> 1-1024       — диапазон
    portscan <host> 80,443,22    — конкретные порты
    portscan <host> 80           — один порт
"""

import sys
import time
import socket
import threading
import queue
import json

NAME    = "portscan"
TITLE   = "Port Scanner"
DESC    = "Сканирование портов цели (аналог nmap)"
USAGE   = "portscan <IP/host> [top|full|<start-end>|<p1,p2>]"
ALIASES = ["ps", "scan", "ports"]

# ─── Топ-100 наиболее распространённых портов ────────────────────
TOP_PORTS = sorted({
    20, 21, 22, 23, 25, 53, 79, 80, 88, 102, 110, 111, 119,
    135, 139, 143, 179, 199, 389, 443, 445, 465, 514, 554, 587,
    631, 636, 902, 993, 995, 1080, 1194, 1433, 1521, 1723, 1900,
    2000, 2049, 2121, 2375, 2376, 3000, 3001, 3306, 3389, 4369,
    4444, 5000, 5432, 5601, 5800, 5900, 5985, 6000, 6379, 6666,
    7001, 7070, 8000, 8001, 8080, 8081, 8082, 8083, 8443, 8888,
    9000, 9001, 9090, 9100, 9200, 10000, 10443, 11211,
    27017, 27018, 28017, 50000,
})

# ─── Словарь сервисов ────────────────────────────────────────────
SERVICES = {
    20: "ftp-data",    21: "ftp",           22: "ssh",
    23: "telnet",      25: "smtp",           53: "dns",
    79: "finger",      80: "http",           88: "kerberos",
    102: "mms",        110: "pop3",          111: "rpcbind",
    119: "nntp",       135: "msrpc",         139: "netbios",
    143: "imap",       179: "bgp",           199: "smux",
    389: "ldap",       443: "https",         445: "smb",
    465: "smtps",      514: "syslog",        554: "rtsp",
    587: "smtp-tls",   631: "ipp",           636: "ldaps",
    902: "iss-realsec",993: "imaps",         995: "pop3s",
    1080: "socks5",    1194: "openvpn",      1433: "mssql",
    1521: "oracle",    1723: "pptp",         1900: "ssdp",
    2000: "cisco-sccp",2049: "nfs",          2121: "ftp-proxy",
    2375: "docker",    2376: "docker-tls",   3000: "grafana/dev",
    3001: "dev-server",3306: "mysql",        3389: "rdp",
    4369: "epmd",      4444: "metasploit",   5000: "flask/upnp",
    5432: "postgresql",5601: "kibana",       5800: "vnc-http",
    5900: "vnc",       5985: "winrm",        6000: "x11",
    6379: "redis",     6666: "irc",          7001: "weblogic",
    7070: "realserver",8000: "http-alt",     8080: "http-proxy",
    8081: "http-alt2", 8082: "http-alt3",    8083: "http-alt4",
    8443: "https-alt", 8888: "jupyter",      9000: "php-fpm",
    9001: "tor",       9090: "prometheus",   9100: "jetdirect",
    9200: "elastic",   10000: "webmin",      10443: "https-alt",
    11211: "memcached",27017: "mongodb",     27018: "mongo-shard",
    28017: "mongo-http",50000: "db2",
}

# ─── Утилиты ─────────────────────────────────────────────────────

def _resolve(target: str):
    try:
        ip = socket.gethostbyname(target)
        try:
            host = socket.gethostbyaddr(ip)[0]
        except Exception:
            host = ip
        return ip, host
    except Exception:
        return "", target


def _check_port(ip: str, port: int, timeout: float) -> bool:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        r = s.connect_ex((ip, port))
        s.close()
        return r == 0
    except Exception:
        return False


def _grab_banner(ip: str, port: int, timeout: float = 1.5) -> str:
    """Получаем баннер сервиса (если он есть)."""
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect((ip, port))
        probes = {
            80:   b"HEAD / HTTP/1.0\r\nHost: " + ip.encode() + b"\r\n\r\n",
            8080: b"HEAD / HTTP/1.0\r\nHost: " + ip.encode() + b"\r\n\r\n",
            8000: b"HEAD / HTTP/1.0\r\nHost: " + ip.encode() + b"\r\n\r\n",
            8888: b"HEAD / HTTP/1.0\r\nHost: " + ip.encode() + b"\r\n\r\n",
            21:   None,   # FTP сам пришлёт
            22:   None,   # SSH сам пришлёт
            25:   None,   # SMTP сам пришлёт
            110:  None,   # POP3 сам пришлёт
            143:  None,   # IMAP сам пришлёт
        }
        probe = probes.get(port, None)
        if probe:
            s.sendall(probe)
        time.sleep(0.2)
        data = s.recv(512)
        s.close()
        banner = data.decode("utf-8", errors="replace").strip()
        banner = " ".join(banner.split())[:80]
        return "".join(c for c in banner if c.isprintable())
    except Exception:
        return ""


# ─── Основной сканер ─────────────────────────────────────────────

def _scan(emit, ip: str, ports: list, timeout: float, threads: int,
          should_stop, do_banner: bool = True):
    open_ports = []
    q_in = queue.Queue()
    for p in ports:
        q_in.put(p)

    lock     = threading.Lock()
    done_cnt = [0]
    total    = len(ports)

    def worker():
        while True:
            try:
                port = q_in.get_nowait()
            except queue.Empty:
                break
            if should_stop():
                break
            if _check_port(ip, port, timeout):
                with lock:
                    open_ports.append(port)
            with lock:
                done_cnt[0] += 1
            q_in.task_done()

    thread_list = []
    for _ in range(min(threads, max(1, len(ports)))):
        t = threading.Thread(target=worker, daemon=True)
        t.start()
        thread_list.append(t)

    last_report = [time.time()]
    while any(t.is_alive() for t in thread_list):
        if should_stop():
            break
        now = time.time()
        if now - last_report[0] >= 2.0:
            with lock:
                d = done_cnt[0]
            pct = d / total * 100 if total else 100
            emit(f"[#5a2a82]  ◆ прогресс: {d}/{total} ({pct:.0f}%) │ "
                 f"открыто: {len(open_ports)}[/]")
            last_report[0] = now
        time.sleep(0.1)

    for t in thread_list:
        t.join(timeout=1)

    open_ports.sort()
    return open_ports


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ PORT SCANNER[/b][/]")
        emit("")
        emit("  [b]portscan <target>[/b]            — топ-100 портов")
        emit("  [b]portscan <target> top[/b]         — топ-100 портов")
        emit("  [b]portscan <target> full[/b]        — все 65535 портов")
        emit("  [b]portscan <target> 1-1024[/b]      — диапазон")
        emit("  [b]portscan <target> 80,443,22[/b]   — список портов")
        emit("")
        emit("[#5a2a82]  пример: portscan 192.168.1.1[/]")
        emit("[#5a2a82]  пример: portscan scanme.nmap.org top[/]")
        return

    parts = args.split(maxsplit=1)
    target = parts[0].strip()
    mode   = parts[1].strip() if len(parts) > 1 else "top"

    # Резолвим
    emit("")
    emit(f"[#a06cd5]◆ цель:[/]   [b]{target}[/]")
    emit("[#5a2a82]◆ резолвю хост…[/]")

    ip, hostname = _resolve(target)
    if not ip:
        emit(f"[#c93a3a]◆ не могу резолвить: {target}[/]")
        return

    emit(f"[#a06cd5]◆ IP:[/]     [b]{ip}[/]")
    if hostname != ip and hostname != target:
        emit(f"[#a06cd5]◆ хост:[/]   [b]{hostname}[/]")

    # Определяем список портов
    if mode in ("top", "", "t"):
        ports = TOP_PORTS[:]
        mode_label = f"топ {len(ports)} портов"
        threads, timeout = 150, 0.7
    elif mode in ("full", "all", "f"):
        ports = list(range(1, 65536))
        mode_label = "полный скан (65535 портов)"
        threads, timeout = 300, 0.5
    elif "-" in mode and "," not in mode:
        try:
            a, b = mode.split("-", 1)
            ports = list(range(int(a), int(b) + 1))
            mode_label = f"диапазон {a}–{b} ({len(ports)} портов)"
            threads, timeout = 150, 0.7
        except Exception:
            emit(f"[#c93a3a]◆ неверный диапазон: {mode}[/]")
            return
    elif "," in mode:
        try:
            ports = sorted({int(p.strip()) for p in mode.split(",") if p.strip().isdigit()})
            mode_label = f"{len(ports)} указанных портов"
            threads, timeout = 50, 1.0
        except Exception:
            emit(f"[#c93a3a]◆ неверные порты: {mode}[/]")
            return
    else:
        try:
            ports = [int(mode)]
            mode_label = f"порт {mode}"
            threads, timeout = 1, 2.0
        except Exception:
            emit(f"[#c93a3a]◆ неизвестный режим: {mode}[/]")
            return

    emit(f"[#a06cd5]◆ режим:[/]  {mode_label}")
    emit(f"[#a06cd5]◆ потоки:[/] {threads}  [#a06cd5]таймаут:[/] {timeout}s")
    emit("[#e94b4b][b]◆ запускаю скан…[/b][/]")
    emit("")

    t_start = time.time()
    open_ports = _scan(emit, ip, ports, timeout=timeout,
                        threads=threads, should_stop=should_stop)
    elapsed = time.time() - t_start

    if should_stop():
        emit("[#c93a3a]◆ скан остановлен[/]")
        return

    emit("")
    if not open_ports:
        emit("[#c93a3a]◆ открытых портов не найдено[/]")
        emit(f"[#5a2a82]  проверено: {len(ports)} портов · время: {elapsed:.1f}с[/]")
        return

    emit(f"[#c93a3a][b]◆ ОТКРЫТЫЕ ПОРТЫ — {ip}[/b][/]")
    emit("")
    emit(f"  [#5a2a82]{'ПОРТ':<8} {'ПРОТОКОЛ':<20} {'БАННЕР'}[/]")
    emit(f"  [#2b0f3a]{'─'*8} {'─'*20} {'─'*45}[/]")

    result_lines = [
        "=" * 70,
        f"  PORTSCAN — {ip}  ({hostname})",
        "=" * 70,
        f"  Режим: {mode_label}",
        f"  Найдено: {len(open_ports)} открытых портов",
        f"  Время: {elapsed:.1f}с",
        "",
        f"  {'ПОРТ':<8} {'СЕРВИС':<20} {'БАННЕР'}",
        "  " + "─" * 70,
    ]

    for port in open_ports:
        if should_stop():
            break
        service = SERVICES.get(port, "unknown")
        banner  = _grab_banner(ip, port, timeout=1.5)

        emit(f"  [#e94b4b][b]{port:<8}[/b][/] "
             f"[#a06cd5]{service:<20}[/] "
             f"[#b794f4]{banner}[/]")

        result_lines.append(f"  {port:<8} {service:<20} {banner}")

    result_lines += ["", "=" * 70]

    emit("")
    emit(f"[#5a2a82]◆ итого: [b]{len(open_ports)}[/b] открытых · "
         f"проверено: [b]{len(ports)}[/b] · время: [b]{elapsed:.1f}с[/b][/]")

    # Модал копирования
    try:
        import json as _json
        emit("@@COPY_SCREEN@@" + _json.dumps({
            "title": f"portscan {ip} — открытые порты",
            "lines": result_lines,
        }, ensure_ascii=False))
    except Exception:
        pass
