"""
Abadon Soft — взломщик хешей (аналог hashcat / john).

Поддерживает: MD5, SHA-1, SHA-256, SHA-512, NTLM, bcrypt-detect.
Атаки: словарная + правила (l33t, CAPS, append123).

Команды:
    hashcrack <хеш>                  — авто-определение + взлом
    hashcrack <хеш> <словарь.txt>    — свой словарь
    hashcrack <хеш> md5              — принудительный тип
    hashcrack identify <хеш>         — только определить тип
"""

import os
import sys
import time
import hashlib
import threading
import json

NAME    = "hashcrack"
TITLE   = "Hash Cracker"
DESC    = "Определение и взлом хешей (MD5/SHA1/SHA256/NTLM)"
USAGE   = "hashcrack <hash> [wordlist] [type]"
ALIASES = ["hash", "crack", "hc"]

# ─── Топ-паролей (встроенный, если нет словаря) ──────────────────
BUILTIN_PASSWORDS = [
    "password","123456","password123","admin","letmein","qwerty",
    "abc123","monkey","1234567","dragon","111111","baseball","iloveyou",
    "master","sunshine","ashley","bailey","passw0rd","shadow","superman",
    "michael","football","12345","princess","azerty","trustno1","000000",
    "donald","charlie","batman","654321","soccer","hockey","ranger",
    "daniel","starwars","klaster","112233","george","asshole","computer",
    "michelle","jessica","pepper","1111","zxcvbn","555555","11111111",
    "131313","freedom","777777","pass","maggie","159753","aaaaaa",
    "ginger","princess","joshua","cheese","amanda","summer","love",
    "ashley","6969","nicole","chelsea","biteme","matthew","access",
    "yankees","987654321","dallas","austin","thunder","taylor","matrix",
    "mobilemail","mom","monitor","monitoring","montana","moon","moscow",
    "password1","qwerty123","1q2w3e4r","test","root","toor","admin123",
    "administrator","changeme","secret","welcome","hello","pass123",
    "12345678","123456789","1234567890","passw0rd","p@ssword","p@ss",
    "abcdef","qwerty","qwertyuiop","asdfghjkl","zxcvbnm","1qaz2wsx",
    "1q2w3e","iloveyou1","starwars1","superman1","batman1","dragon1",
    "monkey1","abc1234","1234abc","pass1234","password12","god","love123",
    "login","hello123","welcome1","test1","admin1","root123","user",
    "user123","guest","guest123","demo","demo123","temp","temp123",
]

# ─── Типы хешей ──────────────────────────────────────────────────
HASH_TYPES = {
    32:  ["md5", "ntlm"],
    40:  ["sha1"],
    56:  ["sha224"],
    64:  ["sha256"],
    96:  ["sha384"],
    128: ["sha512"],
}

HASH_FNS = {
    "md5":    lambda s: hashlib.md5(s).hexdigest(),
    "sha1":   lambda s: hashlib.sha1(s).hexdigest(),
    "sha224": lambda s: hashlib.sha224(s).hexdigest(),
    "sha256": lambda s: hashlib.sha256(s).hexdigest(),
    "sha384": lambda s: hashlib.sha384(s).hexdigest(),
    "sha512": lambda s: hashlib.sha512(s).hexdigest(),
    "ntlm": lambda s: hashlib.new("md4", s.decode("utf-8")
                        .encode("utf-16-le")).hexdigest()
                       if isinstance(s, bytes)
                       else hashlib.new("md4", s.encode("utf-16-le")).hexdigest(),
}

# ─── Правила мутаций ─────────────────────────────────────────────
def _mutate(word: str):
    """Генерим вариации одного пароля."""
    yield word
    yield word.capitalize()
    yield word.upper()
    w = word.lower()
    yield w + "1"
    yield w + "12"
    yield w + "123"
    yield w + "1234"
    yield w + "!"
    yield w + "@"
    # l33t speak
    l33t = word.lower().replace("a","@").replace("e","3").replace("i","1")\
               .replace("o","0").replace("s","$").replace("t","7")
    if l33t != word.lower():
        yield l33t
    yield "!" + w
    yield w + "2024"
    yield w + "2023"


# ─── Утилиты ─────────────────────────────────────────────────────

def _identify(h: str) -> list:
    """Возвращаем список возможных типов хеша."""
    h = h.strip().lower()
    # bcrypt
    if h.startswith("$2b$") or h.startswith("$2a$") or h.startswith("$2y$"):
        return ["bcrypt"]
    # MD5 crypt
    if h.startswith("$1$"):
        return ["md5-crypt"]
    # SHA-512 crypt
    if h.startswith("$6$"):
        return ["sha512-crypt"]
    # sha256-crypt
    if h.startswith("$5$"):
        return ["sha256-crypt"]

    # По длине
    types = HASH_TYPES.get(len(h), [])
    # Проверяем, что только hex
    try:
        int(h, 16)
    except ValueError:
        return ["unknown"]
    return types if types else ["unknown"]


def _load_wordlist(path: str) -> list:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip()]
    except Exception:
        return []


def _find_wordlist() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    for p in (
        os.path.join(here, "wifi_password.txt"),
        os.path.join(root, "wifi_password.txt"),
        os.path.join(here, "passwords.txt"),
        os.path.join(root, "passwords.txt"),
    ):
        if os.path.isfile(p):
            return p
    return ""


def _try_crack(target_hash: str, hash_type: str, passwords: list,
               emit, should_stop, label=""):
    """Словарная атака с мутациями."""
    target_hash = target_hash.strip().lower()
    fn = HASH_FNS.get(hash_type)
    if fn is None:
        return None, 0

    total   = len(passwords)
    tried   = 0
    t0      = time.time()
    last_report = time.time()

    for word in passwords:
        if should_stop():
            return None, tried

        for candidate in _mutate(word):
            if should_stop():
                return None, tried
            try:
                b = candidate.encode("utf-8")
                h = fn(b) if hash_type != "ntlm" else fn(candidate)
                tried += 1
                if h == target_hash:
                    return candidate, tried
            except Exception:
                pass

        # Прогресс
        now = time.time()
        if now - last_report >= 3.0:
            pct = tried / (total * 10) * 100  # ~10 мутаций
            emit(f"[#5a2a82]  ◆ {label}проверено: ~{tried:,} · "
                 f"≈{pct:.0f}% · {tried/(now-t0):.0f}/с[/]")
            last_report = now

    return None, tried


# ─── Команды ─────────────────────────────────────────────────────

def _cmd_identify(emit, h: str):
    types = _identify(h)
    emit(f"[#a06cd5]◆ хеш:[/]   [b]{h}[/]")
    emit(f"[#a06cd5]◆ длина:[/] {len(h)} символов")
    emit(f"[#a06cd5]◆ тип:[/]   [b]{' / '.join(types)}[/]")


def _cmd_crack(emit, h: str, wordlist_path: str = "",
               forced_type: str = "", should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    h = h.strip()
    types = _identify(h)

    emit("")
    emit(f"[#a06cd5]◆ хеш:[/]   [b]{h[:64]}{'…' if len(h)>64 else ''}[/]")
    emit(f"[#a06cd5]◆ тип:[/]   [b]{' / '.join(types)}[/]")

    if types[0] in ("bcrypt", "md5-crypt", "sha512-crypt", "sha256-crypt", "unknown"):
        emit(f"[#c93a3a]◆ словарный взлом {types[0]} не поддерживается[/]")
        if types[0] == "bcrypt":
            emit("[#5a2a82]  → bcrypt требует GPU (hashcat -m 3200)[/]")
        return

    if forced_type and forced_type in HASH_FNS:
        types = [forced_type]
        emit(f"[#a06cd5]◆ принудительно:[/] [b]{forced_type}[/]")

    # Загружаем словарь
    if not wordlist_path:
        wordlist_path = _find_wordlist()
    passwords = _load_wordlist(wordlist_path) if wordlist_path else []

    if passwords:
        emit(f"[#a06cd5]◆ словарь:[/] [dim]{wordlist_path}[/] "
             f"[dim]({len(passwords):,} паролей)[/]")
    else:
        emit("[#5a2a82]◆ словарь не найден — используем встроенный[/]")
        passwords = BUILTIN_PASSWORDS[:]

    passwords = list(dict.fromkeys(passwords))  # дедупликация

    emit("[#e94b4b][b]◆ запускаю перебор…[/b][/]")
    emit("")

    t_start = time.time()

    for hash_type in types:
        if should_stop():
            break
        emit(f"[#5a2a82]◆ атакую как {hash_type.upper()}…[/]")
        found, tried = _try_crack(h.lower(), hash_type, passwords,
                                   emit, should_stop,
                                   label=f"[{hash_type}] ")
        elapsed = time.time() - t_start

        if found is not None:
            emit("")
            emit("[#e94b4b][b]╔══════════════════════════════════════════╗[/b][/]")
            emit("[#e94b4b][b]║         В З Л О М   У С П Е Ш Е Н        ║[/b][/]")
            emit("[#e94b4b][b]╚══════════════════════════════════════════╝[/b][/]")
            emit(f"  [#a06cd5]◆ хеш:[/]     [b]{h[:48]}[/]")
            emit(f"  [#a06cd5]◆ тип:[/]     [b]{hash_type.upper()}[/]")
            emit(f"  [#a06cd5]◆ пароль:[/]  [#e94b4b][b]{found}[/b][/]")
            emit(f"  [#a06cd5]◆ попыток:[/] [b]{tried:,}[/b]")
            emit(f"  [#a06cd5]◆ время:[/]   [b]{elapsed:.2f}с[/b]")
            emit("")
            return

        emit(f"[#5a2a82]  → {hash_type.upper()}: {tried:,} попыток — не найдено[/]")

    elapsed = time.time() - t_start
    emit("")
    emit(f"[#c93a3a]◆ пароль не найден за {elapsed:.1f}с[/]")
    emit("[#5a2a82]  → попробуй больший словарь (rockyou.txt)[/]")
    emit("[#5a2a82]  → или hashcat/john с GPU для быстрого перебора[/]")


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ HASH CRACKER[/b][/]")
        emit("")
        emit("  [b]hashcrack <hash>[/b]              — взломать")
        emit("  [b]hashcrack <hash> <словарь>[/b]    — свой словарь")
        emit("  [b]hashcrack <hash> md5[/b]           — принудительный тип")
        emit("  [b]hashcrack identify <hash>[/b]      — определить тип")
        emit("")
        emit("[#5a2a82]  типы: md5 sha1 sha224 sha256 sha384 sha512 ntlm[/]")
        emit("[#5a2a82]  пример: hashcrack 5f4dcc3b5aa765d61d8327deb882cf99[/]")
        return

    parts = args.split()

    if parts[0].lower() == "identify":
        if len(parts) < 2:
            emit("[#c93a3a]◆ укажи хеш: hashcrack identify <hash>[/]")
            return
        _cmd_identify(emit, parts[1])
        return

    target_hash  = parts[0]
    wordlist_path = ""
    forced_type  = ""

    for p in parts[1:]:
        if os.path.isfile(p):
            wordlist_path = p
        elif p.lower() in HASH_FNS:
            forced_type = p.lower()

    _cmd_crack(emit, target_hash, wordlist_path, forced_type, should_stop)
