"""
Abadon Soft — сканер уязвимостей (аналог nikto / nessus lite).
Проверяет цель на распространённые проблемы безопасности.

Команды:
    vuln <host/IP>         — полная проверка
    vuln <host> web        — только веб-уязвимости
    vuln <host> net        — только сетевые уязвимости
    vuln <host> creds      — стандартные учётные данные
"""

import os
import sys
import time
import socket
import threading
import urllib.request
import urllib.error
import json

NAME    = "vuln"
TITLE   = "Vuln Scanner"
DESC    = "Проверка на распространённые уязвимости (nikto аналог)"
USAGE   = "vuln <IP/host> [web|net|creds]"
ALIASES = ["scan2", "vulns", "check"]

TIMEOUT = 5.0
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# ─── Опасные порты ───────────────────────────────────────────────
DANGEROUS_PORTS = {
    21:    ("FTP",        "Устаревший протокол, передача данных в открытом виде"),
    23:    ("Telnet",     "Небезопасен: всё в открытом виде"),
    25:    ("SMTP",       "Открытый SMTP может быть использован для спама"),
    53:    ("DNS",        "Проверить zone transfer"),
    111:   ("RPCBind",    "Вектор атак на NFS/RPC"),
    135:   ("MS-RPC",     "Целевой порт для exploits (EternalBlue и др.)"),
    139:   ("NetBIOS",    "Атаки на SMB/NetBIOS"),
    389:   ("LDAP",       "Проверить anonymous bind"),
    445:   ("SMB",        "EternalBlue, SMBGhost, PrintNightmare — высокий риск"),
    512:   ("rexec",      "Небезопасный удалённый exec"),
    513:   ("rlogin",     "Небезопасный удалённый вход"),
    514:   ("RSH",        "Remote Shell без аутентификации"),
    1099:  ("Java RMI",   "RCE через десериализацию"),
    2049:  ("NFS",        "Монтирование сетевых дисков без аутентификации"),
    3306:  ("MySQL",      "База данных доступна снаружи"),
    3389:  ("RDP",        "BlueKeep (CVE-2019-0708), BlasteDoor"),
    4444:  ("Metasploit", "Возможно скомпрометировано!"),
    5432:  ("PostgreSQL", "База данных доступна снаружи"),
    5900:  ("VNC",        "Часто без пароля или слабый пароль"),
    6379:  ("Redis",      "Часто без аутентификации — полный доступ к данным"),
    8080:  ("HTTP-alt",   "Проверить на default страницу/панель"),
    8443:  ("HTTPS-alt",  "Проверить на default страницу/панель"),
    9200:  ("Elastic",    "Elasticsearch без аутентификации — утечка данных"),
    11211: ("Memcached",  "Без аутентификации + DDoS amplification"),
    27017: ("MongoDB",    "MongoDB без аутентификации — утечка данных"),
    50000: ("DB2",        "База данных доступна снаружи"),
}

# ─── Стандартные учётки ──────────────────────────────────────────
DEFAULT_CREDS = {
    "router":  [("admin","admin"), ("admin","password"), ("admin",""),
                ("admin","1234"), ("root","root"), ("user","user"),
                ("admin","admin123")],
    "ssh":     [("root","root"), ("admin","admin"), ("root",""),
                ("pi","raspberry"), ("ubuntu","ubuntu"), ("vagrant","vagrant"),
                ("admin","password"), ("test","test")],
    "mysql":   [("root",""), ("root","root"), ("root","mysql"),
                ("admin","admin"), ("mysql","mysql")],
    "redis":   [("",""), ("redis","redis")],  # usually no auth
    "mongo":   [("admin","admin"), ("admin","")],
}

# ─── Уязвимые веб-пути ───────────────────────────────────────────
VULN_PATHS = [
    ("/.git/HEAD",                 "Git репозиторий раскрыт"),
    ("/.env",                      "Файл .env с секретами раскрыт"),
    ("/wp-config.php.bak",         "Резервная копия конфига WordPress"),
    ("/wp-admin/",                  "WordPress admin панель"),
    ("/phpmyadmin/",               "phpMyAdmin доступен"),
    ("/pma/",                      "phpMyAdmin (pma) доступен"),
    ("/adminer.php",               "Adminer (DB GUI) доступен"),
    ("/config.php",                "Конфиг PHP раскрыт"),
    ("/config.yml",                "Конфиг YAML раскрыт"),
    ("/config.json",               "Конфиг JSON раскрыт"),
    ("/database.yml",              "Конфиг БД раскрыт"),
    ("/composer.json",             "composer.json — зависимости раскрыты"),
    ("/package.json",              "package.json — зависимости раскрыты"),
    ("/api/",                      "API endpoint доступен"),
    ("/swagger/",                  "Swagger UI доступен"),
    ("/swagger-ui.html",           "Swagger UI раскрывает API"),
    ("/actuator/",                 "Spring Actuator (RCE риск)"),
    ("/actuator/env",              "Spring Actuator — переменные среды"),
    ("/console",                   "Консоль приложения"),
    ("/server-status",             "Apache server-status"),
    ("/nginx_status",              "Nginx status page"),
    ("/elmah.axd",                 "ELMAH — лог ошибок .NET"),
    ("/trace.axd",                 "trace.axd — .NET диагностика"),
    ("/phpinfo.php",               "phpinfo() раскрывает конфигурацию"),
    ("/info.php",                  "phpinfo() раскрывает конфигурацию"),
    ("/test.php",                  "Тестовый PHP файл"),
    ("/xmlrpc.php",                "WordPress XML-RPC (brute risk)"),
    ("/.htaccess",                 ".htaccess раскрыт"),
    ("/web.config",                "web.config раскрыт"),
    ("/.ssh/id_rsa",               "Приватный SSH ключ раскрыт!"),
    ("/backup.zip",                "Резервная копия (zip)"),
    ("/backup.tar.gz",             "Резервная копия (tar.gz)"),
    ("/robots.txt",                "robots.txt (карта запрещённых путей)"),
]

# ─── Утилиты ─────────────────────────────────────────────────────

def _check_port(ip: str, port: int, timeout: float = 2.0) -> bool:
    try:
        s = socket.socket()
        s.settimeout(timeout)
        r = s.connect_ex((ip, port))
        s.close()
        return r == 0
    except Exception:
        return False


def _http_check(url: str) -> tuple:
    """(status, body_preview). 0 если недоступен."""
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "AbadonSoft/1.0"}
        )
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            body = r.read(512).decode("utf-8", errors="ignore")
            return r.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


def _resolve(host: str) -> str:
    try:
        return socket.gethostbyname(host)
    except Exception:
        return host


# ─── Проверки ────────────────────────────────────────────────────

SEVERITY = {"CRITICAL": "#e94b4b", "HIGH": "#c93a3a",
            "MEDIUM": "#a06cd5", "LOW": "#b794f4", "INFO": "#5a2a82"}

def _emit_vuln(emit, severity: str, title: str, detail: str = ""):
    color = SEVERITY.get(severity, "#b794f4")
    sev_s = f"[bold {color}]{severity:<8}[/bold {color}]"
    emit(f"  {sev_s}  [{color}]{title}[/]")
    if detail:
        emit(f"            [dim]{detail}[/dim]")


def _check_net(emit, ip: str, should_stop, findings: list):
    emit("[#c93a3a][b]◆ СЕТЕВЫЕ УЯЗВИМОСТИ[/b][/]")
    emit("")

    open_dangerous = []
    for port, (svc, note) in sorted(DANGEROUS_PORTS.items()):
        if should_stop():
            return
        if _check_port(ip, port, timeout=1.5):
            open_dangerous.append((port, svc, note))

    if not open_dangerous:
        emit("  [#5a2a82]◆ опасных открытых портов не обнаружено[/]")
        return

    for port, svc, note in open_dangerous:
        sev = "CRITICAL" if port in (4444, 445, 23, 512, 513, 514) else \
              "HIGH"     if port in (21, 3389, 6379, 9200, 27017) else "MEDIUM"
        _emit_vuln(emit, sev, f"Открытый порт {port}/{svc}", note)
        findings.append({"sev": sev, "title": f"Открытый порт {port}/{svc}",
                          "detail": note})

    # SMB: проверка наличия (опасный)
    if any(p in [p for p, *_ in open_dangerous] for p in [445, 139]):
        _emit_vuln(emit, "HIGH",
                   "SMB открыт — риск EternalBlue/SMBGhost",
                   "Убедись что патчи KB4013389 / KB4540673 установлены")

    # Redis без авторизации
    if 6379 in [p for p, *_ in open_dangerous]:
        try:
            s = socket.socket()
            s.settimeout(2.0)
            s.connect((ip, 6379))
            s.sendall(b"PING\r\n")
            r = s.recv(32)
            s.close()
            if b"+PONG" in r:
                _emit_vuln(emit, "CRITICAL",
                           "Redis без аутентификации",
                           "redis-cli -h {ip} — полный доступ без пароля!")
                findings.append({"sev": "CRITICAL",
                                  "title": "Redis без аутентификации"})
        except Exception:
            pass

    # MongoDB без авторизации
    if 27017 in [p for p, *_ in open_dangerous]:
        _emit_vuln(emit, "CRITICAL",
                   "MongoDB открыт (возможно без аутентификации)",
                   "Проверь: mongo --host " + ip)
        findings.append({"sev": "CRITICAL", "title": "MongoDB открыт"})


def _check_web(emit, base_url: str, should_stop, findings: list):
    emit("[#c93a3a][b]◆ ВЕБ-УЯЗВИМОСТИ[/b][/]")
    emit("")

    found_paths = []
    total = len(VULN_PATHS)

    for i, (path, desc) in enumerate(VULN_PATHS):
        if should_stop():
            return
        url = base_url.rstrip("/") + path
        code, body = _http_check(url)
        if code in (200, 204, 206, 401, 403):
            sev = "CRITICAL" if any(x in path for x in
                                    [".env", ".git", "id_rsa", "backup",
                                     "phpinfo", "test.php", "elmah"]) else \
                  "HIGH"     if any(x in path for x in
                                    ["config", "phpmyadmin", "swagger",
                                     "actuator", "xmlrpc", "console"]) else "MEDIUM"
            emit_desc = f"{desc}  [HTTP {code}]"
            if code in (401, 403):
                sev = "INFO"
                emit_desc += " (доступ ограничен — но путь существует)"
            _emit_vuln(emit, sev, path, emit_desc)
            findings.append({"sev": sev, "title": path, "detail": emit_desc})
            found_paths.append((path, code, desc))
        if i % 5 == 0:
            pct = i / total * 100
            emit(f"[#5a2a82]  ◆ веб-проверка: {i}/{total} ({pct:.0f}%)[/]")

    # Проверка HTTP-заголовков безопасности
    code, body = _http_check(base_url)
    if code:
        try:
            req = urllib.request.Request(
                base_url,
                headers={"User-Agent": "AbadonSoft/1.0"}
            )
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                heads = {k.lower(): v for k, v in r.headers.items()}
            missing = []
            if "x-frame-options" not in heads:
                missing.append("X-Frame-Options (Clickjacking)")
            if "strict-transport-security" not in heads:
                missing.append("HSTS")
            if "content-security-policy" not in heads:
                missing.append("CSP")
            if "x-xss-protection" not in heads:
                missing.append("X-XSS-Protection")
            if "x-content-type-options" not in heads:
                missing.append("X-Content-Type-Options")
            if missing:
                _emit_vuln(emit, "MEDIUM",
                           "Отсутствуют заголовки безопасности",
                           ", ".join(missing))
            if "x-powered-by" in heads:
                _emit_vuln(emit, "LOW",
                           f"X-Powered-By раскрывает технологию: {heads['x-powered-by']}")
            if "server" in heads:
                _emit_vuln(emit, "LOW",
                           f"Server header раскрывает версию: {heads['server']}")
        except Exception:
            pass

    if not found_paths:
        emit("  [#5a2a82]◆ уязвимых путей не обнаружено[/]")


def _check_creds(emit, ip: str, should_stop, findings: list):
    emit("[#c93a3a][b]◆ СТАНДАРТНЫЕ УЧЁТНЫЕ ДАННЫЕ[/b][/]")
    emit("")

    # Проверяем Redis
    if _check_port(ip, 6379, 1.5) and not should_stop():
        try:
            s = socket.socket()
            s.settimeout(2.0)
            s.connect((ip, 6379))
            s.sendall(b"PING\r\n")
            r = s.recv(32)
            s.close()
            if b"+PONG" in r:
                _emit_vuln(emit, "CRITICAL", "Redis: нет пароля", f"{ip}:6379")
                findings.append({"sev":"CRITICAL","title":"Redis: нет пароля"})
        except Exception:
            pass

    # FTP анонимный
    if _check_port(ip, 21, 1.5) and not should_stop():
        try:
            s = socket.socket()
            s.settimeout(3.0)
            s.connect((ip, 21))
            banner = s.recv(256)
            s.sendall(b"USER anonymous\r\n")
            r1 = s.recv(64)
            s.sendall(b"PASS anon@anon.com\r\n")
            r2 = s.recv(64)
            s.close()
            if b"230" in r2:  # 230 = Login successful
                _emit_vuln(emit, "CRITICAL",
                           "FTP: анонимный вход разрешён!", f"{ip}:21")
                findings.append({"sev":"CRITICAL","title":"FTP: анон вход"})
        except Exception:
            pass

    # Проверяем default HTTP страницы (роутеры)
    for port in [80, 8080, 443, 8443]:
        if should_stop():
            break
        if not _check_port(ip, port, 1.0):
            continue
        scheme = "https" if port in (443, 8443) else "http"
        url = f"{scheme}://{ip}:{port}/"
        code, body = _http_check(url)
        if code in (200, 401, 403):
            body_lower = body.lower()
            signatures = [
                ("MikroTik", "RouterOS/Winbox"),
                ("D-Link", "D-Link роутер"),
                ("TP-Link", "TP-Link роутер"),
                ("ASUS", "ASUS роутер"),
                ("NETGEAR", "NETGEAR роутер"),
                ("Cisco", "Cisco устройство"),
                ("phpMyAdmin", "phpMyAdmin"),
                ("cPanel", "cPanel хостинг-панель"),
                ("Jenkins", "Jenkins CI (возможна уязвимость)"),
                ("Grafana", "Grafana дашборд"),
            ]
            for sig, label in signatures:
                if sig.lower() in body_lower:
                    sev = "MEDIUM" if code == 200 else "LOW"
                    _emit_vuln(emit, sev,
                               f"{label} обнаружен на {port}/tcp",
                               f"Проверь: {url}")
                    break

    emit("")


# ─── Полная проверка ─────────────────────────────────────────────

def _cmd_full(emit, target: str, should_stop):
    ip = _resolve(target)
    emit(f"[#a06cd5]◆ цель:[/]  [b]{target}[/]")
    if ip != target:
        emit(f"[#a06cd5]◆ IP:[/]    [b]{ip}[/]")
    emit("")

    findings = []
    t_start  = time.time()

    # Определяем базовый URL
    base_url = f"http://{ip}"
    if _check_port(ip, 443, 1.5):
        base_url = f"https://{ip}"
    elif _check_port(ip, 80, 1.5):
        base_url = f"http://{ip}"

    _check_net(emit, ip, should_stop, findings)
    emit("")
    if should_stop(): return

    if _check_port(ip, 80, 1.5) or _check_port(ip, 443, 1.5) \
       or _check_port(ip, 8080, 1.5):
        _check_web(emit, base_url, should_stop, findings)
        emit("")
        if should_stop(): return

    _check_creds(emit, ip, should_stop, findings)

    elapsed = time.time() - t_start

    emit("")
    emit(f"[#c93a3a][b]◆ ИТОГ ({len(findings)} находок · {elapsed:.0f}с)[/b][/]")
    emit("")

    by_sev = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": [], "INFO": []}
    for f in findings:
        by_sev.get(f["sev"], by_sev["INFO"]).append(f)

    for sev, items in by_sev.items():
        if items:
            color = SEVERITY[sev]
            for item in items:
                emit(f"  [bold {color}]{sev:<8}[/bold {color}]  {item['title']}")

    if not findings:
        emit("  [#5a2a82]Явных уязвимостей не обнаружено[/]")
        emit("  [dim](Это не гарантирует безопасность — используй nessus/burp для полного анализа)[/dim]")

    result_lines = ["=" * 70, f"  VULN SCAN — {target}", "=" * 70, ""]
    for f in findings:
        result_lines.append(f"  [{f['sev']}]  {f['title']}")
        if f.get("detail"):
            result_lines.append(f"         {f['detail']}")
    result_lines += ["", "=" * 70]

    try:
        emit("@@COPY_SCREEN@@" + json.dumps({
            "title": f"vuln {target}",
            "lines": result_lines,
        }, ensure_ascii=False))
    except Exception:
        pass


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip()

    if not args or args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ VULNERABILITY SCANNER[/b][/]")
        emit("")
        emit("  [b]vuln <host>[/b]          — полная проверка")
        emit("  [b]vuln <host> web[/b]      — только веб")
        emit("  [b]vuln <host> net[/b]      — только сеть")
        emit("  [b]vuln <host> creds[/b]    — только учётные данные")
        emit("")
        emit("[#5a2a82]  пример: vuln 192.168.1.1[/]")
        return

    parts  = args.split()
    target = parts[0]
    mode   = parts[1].lower() if len(parts) > 1 else "full"
    ip     = _resolve(target)

    emit("")

    findings = []

    if mode in ("full", "all"):
        _cmd_full(emit, target, should_stop)
    elif mode in ("net", "network", "n"):
        emit(f"[#a06cd5]◆ цель:[/] [b]{target} ({ip})[/]")
        emit("")
        _check_net(emit, ip, should_stop, findings)
    elif mode in ("web", "http", "w"):
        base_url = f"http://{ip}"
        emit(f"[#a06cd5]◆ цель:[/] [b]{base_url}[/]")
        emit("")
        _check_web(emit, base_url, should_stop, findings)
    elif mode in ("creds", "cred", "c", "auth"):
        emit(f"[#a06cd5]◆ цель:[/] [b]{target} ({ip})[/]")
        emit("")
        _check_creds(emit, ip, should_stop, findings)
    else:
        emit(f"[#c93a3a]◆ неизвестный режим: {mode}[/]")
        emit("[#5a2a82]  → vuln <host> [full|web|net|creds][/]")
