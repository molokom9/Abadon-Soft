"""
Abadon Soft — сниффер пакетов (аналог tcpdump/Wireshark).
Использует Scapy. Требует прав администратора + Npcap (Win).

Команды:
    sniffer              — слушать всё, 50 пакетов
    sniffer tcp          — только TCP
    sniffer udp          — только UDP
    sniffer http         — только HTTP (порты 80/8080)
    sniffer dns          — только DNS (порт 53)
    sniffer arp          — только ARP
    sniffer icmp         — только ICMP (ping)
    sniffer <N>          — N пакетов (например sniffer 100)
    sniffer tcp 200      — TCP, 200 пакетов
"""

import sys
import time
import ctypes

NAME    = "sniffer"
TITLE   = "Packet Sniffer"
DESC    = "Перехват пакетов в сети (tcpdump/Wireshark аналог)"
USAGE   = "sniffer [tcp|udp|http|dns|arp|icmp] [кол-во]"
ALIASES = ["sniff", "cap", "capture"]

_COUNTER = [0]

# ─── Утилиты ─────────────────────────────────────────────────────

def _is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return True


def _require_scapy():
    try:
        import scapy.all as scapy
        return scapy
    except ImportError:
        return None


def _proto_label(pkt, scapy) -> str:
    """Определяем протокол пакета."""
    if pkt.haslayer(scapy.ARP):   return "ARP"
    if pkt.haslayer(scapy.ICMP):  return "ICMP"
    if pkt.haslayer(scapy.DNS):   return "DNS"
    if pkt.haslayer(scapy.TCP):
        sport = pkt[scapy.TCP].sport
        dport = pkt[scapy.TCP].dport
        if 80 in (sport, dport) or 8080 in (sport, dport): return "HTTP"
        if 443 in (sport, dport):                           return "HTTPS"
        if 22 in (sport, dport):                            return "SSH"
        if 21 in (sport, dport):                            return "FTP"
        if 25 in (sport, dport) or 587 in (sport, dport):  return "SMTP"
        return "TCP"
    if pkt.haslayer(scapy.UDP):   return "UDP"
    return "OTHER"


def _fmt_pkt(pkt, scapy) -> str:
    """Форматируем пакет для вывода."""
    try:
        proto = _proto_label(pkt, scapy)
        ts    = time.strftime("%H:%M:%S")

        # IP-уровень
        if pkt.haslayer(scapy.IP):
            src = pkt[scapy.IP].src
            dst = pkt[scapy.IP].dst
            length = len(pkt)

            # TCP/UDP — порты
            sport, dport = "", ""
            if pkt.haslayer(scapy.TCP):
                sport = pkt[scapy.TCP].sport
                dport = pkt[scapy.TCP].dport
                flags  = pkt[scapy.TCP].flags
                flag_s = str(flags) if flags else ""
                detail = f":{sport} → :{dport}  [{flag_s}]"
            elif pkt.haslayer(scapy.UDP):
                sport = pkt[scapy.UDP].sport
                dport = pkt[scapy.UDP].dport
                detail = f":{sport} → :{dport}"
            else:
                detail = ""

            # DNS — доп. инфо
            dns_q = ""
            if pkt.haslayer(scapy.DNS) and pkt[scapy.DNS].qr == 0:
                try:
                    dns_q = f"  Q:{pkt[scapy.DNS].qd.qname.decode().rstrip('.')}"
                except Exception:
                    pass

            # HTTP payload (первая строка)
            http_info = ""
            if proto in ("HTTP",) and pkt.haslayer(scapy.Raw):
                try:
                    raw = pkt[scapy.Raw].load.decode("utf-8", errors="ignore")
                    first = raw.split("\r\n")[0][:60]
                    http_info = f"  [{first}]"
                except Exception:
                    pass

            line = (f"[dim]{ts}[/dim]  "
                    f"[#e94b4b]{proto:<6}[/]  "
                    f"[#b794f4]{src:<15}[/] → [#a06cd5]{dst:<15}[/]  "
                    f"[dim]{detail}{dns_q}{http_info}  {length}b[/dim]")

        # ARP
        elif pkt.haslayer(scapy.ARP):
            op   = "who-has" if pkt[scapy.ARP].op == 1 else "is-at"
            src  = pkt[scapy.ARP].psrc
            dst  = pkt[scapy.ARP].pdst
            hwsrc= pkt[scapy.ARP].hwsrc
            line = (f"[dim]{ts}[/dim]  "
                    f"[#e94b4b]ARP   [/]  "
                    f"[#b794f4]{src:<15}[/] {op:<10} [#a06cd5]{dst:<15}[/]  "
                    f"[dim]{hwsrc}[/dim]")
        else:
            line = f"[dim]{ts}  OTHER  {pkt.summary()[:80]}[/dim]"

        return line
    except Exception as e:
        return f"[dim]{time.strftime('%H:%M:%S')}  ???  {str(e)[:60]}[/dim]"


# ─── Точка входа ─────────────────────────────────────────────────

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip().lower()

    if args in ("help", "?", "h"):
        emit("[#c93a3a][b]◆ PACKET SNIFFER[/b][/]")
        emit("")
        emit("  [b]sniffer[/b]             — 50 пакетов, всё")
        emit("  [b]sniffer tcp[/b]         — только TCP")
        emit("  [b]sniffer udp[/b]         — только UDP")
        emit("  [b]sniffer http[/b]        — HTTP трафик")
        emit("  [b]sniffer dns[/b]         — DNS запросы")
        emit("  [b]sniffer arp[/b]         — ARP (кто в сети)")
        emit("  [b]sniffer icmp[/b]        — ICMP (ping)")
        emit("  [b]sniffer 200[/b]         — 200 пакетов")
        emit("  [b]sniffer tcp 200[/b]     — TCP, 200 пакетов")
        emit("")
        emit("[#5a2a82]  [b]stop[/b] — чтобы остановить[/]")
        return

    if not _is_admin():
        emit("[#c93a3a]◆ нужны права администратора[/]")
        return

    scapy = _require_scapy()
    if scapy is None:
        emit("[#c93a3a]◆ scapy не установлен[/]")
        emit("[#5a2a82]  → должен установиться автоматически при запуске[/]")
        return

    # Парсим аргументы
    parts = args.split()
    proto_filter = ""
    count = 50

    for p in parts:
        if p.isdigit():
            count = int(p)
        elif p in ("tcp", "udp", "http", "https", "dns", "arp", "icmp", "all"):
            proto_filter = p

    # Строим BPF-фильтр для Scapy
    bpf_map = {
        "tcp":   "tcp",
        "udp":   "udp",
        "http":  "tcp port 80 or tcp port 8080",
        "https": "tcp port 443",
        "dns":   "udp port 53 or tcp port 53",
        "arp":   "arp",
        "icmp":  "icmp",
        "all":   "",
        "":      "",
    }
    bpf = bpf_map.get(proto_filter, "")

    emit("")
    emit(f"[#c93a3a][b]◆ PACKET SNIFFER — СТАРТ[/b][/]")
    emit(f"[#a06cd5]◆ фильтр:[/]   [b]{proto_filter or 'все протоколы'}[/]")
    emit(f"[#a06cd5]◆ пакетов:[/]  [b]{count}[/]")
    if sys.platform == "win32":
        emit("[#5a2a82]◆ интерфейс: первый доступный (Npcap)[/]")
    emit("[#e94b4b][b]◆ слушаю трафик… (stop — остановить)[/b][/]")
    emit("")
    emit(f"  [#5a2a82]{'ВРЕМЯ':<8} {'ПРОТО':<7} {'ИСТОЧНИК':<17} {'ЦЕЛЬ':<17} ДЕТАЛИ[/]")
    emit(f"  [#2b0f3a]{'─'*8} {'─'*7} {'─'*17} {'─'*17} {'─'*30}[/]")

    captured = [0]
    t_start  = time.time()

    def pkt_handler(pkt):
        if should_stop():
            return True   # Scapy < 2.6: return True не используется как стоп
        line = _fmt_pkt(pkt, scapy)
        emit(line)
        captured[0] += 1

    # Запускаем sniff в своём потоке, чтобы should_stop работал
    import threading

    def _sniff():
        try:
            kwargs = {
                "prn":        pkt_handler,
                "count":      count,
                "store":      False,
            }
            if bpf:
                kwargs["filter"] = bpf
            # stop_filter поддерживается в Scapy
            kwargs["stop_filter"] = lambda p: should_stop()
            scapy.sniff(**kwargs)
        except Exception as e:
            emit(f"[#c93a3a]◆ ошибка sniff: {e}[/]")

    t = threading.Thread(target=_sniff, daemon=True)
    t.start()

    # Ждём завершения или stop
    while t.is_alive():
        if should_stop():
            break
        time.sleep(0.3)

    t.join(timeout=3)

    elapsed = time.time() - t_start
    emit("")
    emit(f"[#c93a3a]◆ захвачено пакетов: [b]{captured[0]}[/b] · "
         f"время: {elapsed:.1f}с[/]")
