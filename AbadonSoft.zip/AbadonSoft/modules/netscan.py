"""
Abadon Soft — сетевой сканер.

После скана открывается окно со списком всех устройств —
клик по строке копирует её в буфер обмена.

Команды:
    netscan               — полный скан
    netscan fast          — только ping sweep
    netscan copy          — открыть окно копирования ещё раз
    netscan save          — сохранить в netscan_results.txt
    netscan help          — справка
"""

import os
import re
import sys
import json
import time
import socket
import subprocess
import concurrent.futures

NAME    = "netscan"
TITLE   = "Network Scanner"
DESC    = "Находит все устройства в локальной сети"
USAGE   = "netscan [fast|copy|save]"
ALIASES = ["ns", "net", "lan"]

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

PING_TIMEOUT_MS  = 500
PING_BATCH       = 60
PORT_TIMEOUT     = 0.6

FINGERPRINT_PORTS = [22, 80, 135, 139, 443, 445, 548, 554, 3389,
                     5555, 5900, 8080, 8443, 9100, 62078]

SERVICES = {
    22: "ssh",   80: "http",    135: "msrpc",  139: "netbios",
    443: "https", 445: "smb",   548: "afp",    554: "rtsp",
    3389: "rdp",  5555: "adb",  5900: "vnc",   8080: "http-alt",
    8443: "https-alt", 9100: "printer", 62078: "iphone-sync",
}

_LAST_RESULT = {"lines": [], "path": ""}


# ══════════════════════════════════════════════════════════════════
#  OUI
# ══════════════════════════════════════════════════════════════════

_OUI = {
    "f0:18:98": "Apple", "28:cf:e9": "Apple", "3c:22:fb": "Apple",
    "a8:5c:2c": "Apple", "5c:f3:70": "Apple", "dc:a4:ca": "Apple",
    "84:38:35": "Apple", "44:00:10": "Apple", "d8:96:95": "Apple",
    "08:66:98": "Apple", "20:c9:d0": "Apple", "64:b9:e8": "Apple",
    "00:1b:44": "Samsung", "30:19:66": "Samsung", "50:cc:f8": "Samsung",
    "8c:77:12": "Samsung", "f4:0e:22": "Samsung", "ac:5f:3e": "Samsung",
    "c8:19:f7": "Samsung", "78:1f:db": "Samsung", "e4:7c:f9": "Samsung",
    "e4:5f:01": "Xiaomi", "34:ce:00": "Xiaomi", "50:8f:4c": "Xiaomi",
    "64:cc:2e": "Xiaomi", "28:6c:07": "Xiaomi", "ac:c1:ee": "Xiaomi",
    "ec:f0:0e": "Xiaomi", "f8:a4:5f": "Xiaomi", "78:11:dc": "Xiaomi",
    "04:cf:8c": "Xiaomi", "10:2a:b3": "Xiaomi",
    "00:e0:fc": "Huawei", "48:62:76": "Huawei", "5c:7d:5e": "Huawei",
    "00:66:4b": "Huawei", "24:69:a5": "Huawei", "e0:24:7f": "Huawei",
    "34:c9:3d": "Intel", "8c:c6:81": "Intel", "a4:6b:b6": "Intel",
    "dc:2c:6e": "Intel", "f8:63:3f": "Intel", "94:e6:f7": "Intel",
    "e8:6a:64": "Intel", "ac:74:b1": "Intel",
    "b0:be:76": "TP-Link", "14:cc:20": "TP-Link", "50:c7:bf": "TP-Link",
    "60:32:b1": "TP-Link", "70:4f:57": "TP-Link", "a4:2b:b0": "TP-Link",
    "f4:f2:6d": "TP-Link", "9c:a2:f4": "TP-Link", "c0:06:c3": "TP-Link",
    "00:1e:58": "D-Link", "1c:bd:b9": "D-Link", "78:54:2e": "D-Link",
    "00:24:b2": "Netgear", "b0:39:56": "Netgear", "9c:3d:cf": "Netgear",
    "00:14:d1": "TRENDnet", "00:15:6d": "Ubiquiti",
    "dc:9f:db": "Ubiquiti", "78:8a:20": "Ubiquiti", "24:a4:3c": "Ubiquiti",
    "00:0c:42": "MikroTik", "4c:5e:0c": "MikroTik", "6c:3b:6b": "MikroTik",
    "dc:2c:6e": "Zyxel", "5c:f4:ab": "Zyxel",
    "44:65:0d": "Amazon", "68:37:e9": "Amazon", "84:d6:d0": "Amazon",
    "f0:27:2d": "Amazon", "b4:7c:9c": "Amazon", "fc:65:de": "Amazon",
    "00:1a:11": "Google", "3c:5a:b4": "Google", "f4:f5:d8": "Google",
    "d8:6c:63": "Google", "9c:4f:cf": "Google",
    "8c:3a:e3": "LG", "10:f1:f2": "LG", "a8:16:b2": "LG",
    "c4:36:6c": "LG", "d8:d4:3c": "LG",
    "30:f9:ed": "Sony", "00:04:1f": "Sony", "18:5a:58": "Sony",
    "84:0d:8e": "Espressif", "b4:e6:2d": "Espressif",
    "24:6f:28": "Espressif", "3c:71:bf": "Espressif",
    "a0:20:a6": "Espressif", "dc:4f:22": "Espressif",
    "8c:aa:b5": "Espressif", "5c:cf:7f": "Espressif",
    "ec:fa:bc": "Espressif", "68:c6:3a": "Espressif",
    "50:ec:50": "Tuya", "10:52:1c": "Tuya", "68:57:2d": "Tuya",
    "b8:27:eb": "RaspberryPi", "dc:a6:32": "RaspberryPi",
    "e4:5f:01": "RaspberryPi", "28:cd:c1": "RaspberryPi",
    "00:0c:29": "VMware", "00:05:69": "VMware", "00:50:56": "VMware",
    "08:00:27": "VirtualBox", "0a:00:27": "VirtualBox",
    "00:00:48": "Seiko Epson", "00:1b:a9": "Brother",
    "00:80:77": "Brother", "3c:2a:f4": "Brother",
    "64:09:80": "Xiaomi", "78:02:f8": "Xiaomi", "50:64:2b": "Xiaomi",
    "c0:ee:fb": "Realme", "d0:11:e5": "Realme",
    "9c:2e:a1": "OnePlus", "64:a2:f9": "OnePlus",
    "f8:98:b9": "Oppo", "4c:74:03": "Vivo",
}


def _vendor_for(mac: str) -> str:
    return _OUI.get((mac or "").lower()[:8], "—")


# ══════════════════════════════════════════════════════════════════
#  СЕТЕВОЕ
# ══════════════════════════════════════════════════════════════════

def _run(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout,
                           creationflags=_NO_WINDOW)
        raw = r.stdout or b""
        for enc in ("cp866", "cp1251", "utf-8"):
            try:
                return raw.decode(enc)
            except Exception:
                continue
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return ""


def _get_my_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def _get_gw() -> str:
    txt = _run(["route", "print", "0.0.0.0"], timeout=5)
    for line in txt.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[0] == "0.0.0.0" and parts[1] == "0.0.0.0":
            cand = parts[2]
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", cand) and cand != "0.0.0.0":
                return cand
    return ""


def _arp_table():
    txt = _run(["arp", "-a"], timeout=10)
    entries = []
    for line in txt.splitlines():
        m = re.match(
            r"^\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})\s+(\S+)?",
            line,
        )
        if not m:
            continue
        ip  = m.group(1)
        mac = m.group(2).lower().replace("-", ":")
        if mac in ("ff:ff:ff:ff:ff:ff", "00:00:00:00:00:00"):
            continue
        if mac.startswith(("01:00:5e", "33:33:")):
            continue
        if int(ip.split(".")[0]) >= 224:
            continue
        entries.append((ip, mac))
    return entries


def _ping_sweep(base: str):
    ips = [f"{base}.{i}" for i in range(1, 255)]
    for start in range(0, len(ips), PING_BATCH):
        chunk = ips[start:start + PING_BATCH]
        procs = []
        for ip in chunk:
            try:
                p = subprocess.Popen(
                    ["ping", "-n", "1", "-w", str(PING_TIMEOUT_MS), ip],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=_NO_WINDOW,
                )
                procs.append(p)
            except Exception:
                pass
        for p in procs:
            try:
                p.wait(timeout=2.0)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


def _udp_broadcast_probe(my_ip: str):
    if not my_ip:
        return
    base = my_ip.rsplit(".", 1)[0]
    bc   = base + ".255"
    probes = [
        (5353, b"\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00"),
        (1900, b"M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
               b"MAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n"),
        (137,  b"\x82\x28\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00"
               b" CKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\x00\x00\x21\x00\x01"),
    ]
    for port, payload in probes:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.settimeout(0.05)
            s.sendto(payload, (bc, port))
            s.close()
        except Exception:
            pass


def _ssdp_mcast():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        s.settimeout(0.05)
        payload = (b"M-SEARCH * HTTP/1.1\r\n"
                   b"HOST: 239.255.255.250:1900\r\n"
                   b"MAN: \"ssdp:discover\"\r\nMX: 1\r\n"
                   b"ST: ssdp:all\r\n\r\n")
        s.sendto(payload, ("239.255.255.250", 1900))
        s.close()
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════
#  ПОРТЫ
# ══════════════════════════════════════════════════════════════════

def _check_port(ip: str, port: int):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(PORT_TIMEOUT)
            if s.connect_ex((ip, port)) == 0:
                return port
    except Exception:
        pass
    return None


def _scan_ports_for(ip: str, ports=None):
    ports = ports or FINGERPRINT_PORTS
    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as ex:
        futs = {ex.submit(_check_port, ip, p): p for p in ports}
        for fut in concurrent.futures.as_completed(futs):
            try:
                res = fut.result()
                if res:
                    open_ports.append(res)
            except Exception:
                pass
    return sorted(open_ports)


def _guess_type(vendor: str, ports, is_gw: bool) -> str:
    if is_gw:
        return "router"
    v = (vendor or "").lower()
    has = lambda *ps: any(p in ports for p in ps)
    if has(62078):              return "iPhone"
    if has(5555):               return "Android"
    if has(3389) and has(445):  return "PC (Windows)"
    if has(445) and has(139):
        return "Mac (SMB)" if "apple" in v else "PC (Windows)"
    if has(22) and not has(445):
        return "Mac" if "apple" in v else "Linux"
    if has(548):                return "Mac (AFP)"
    if has(9100):               return "printer"
    if has(554):                return "camera/IP-cam"
    if "espressif" in v or "tuya" in v: return "IoT"
    if "raspberry" in v:        return "Raspberry Pi"
    if "amazon" in v:           return "Amazon device"
    if "google" in v:           return "Google device"
    if "apple" in v:            return "Apple device"
    if "samsung" in v:          return "Samsung"
    if "xiaomi" in v:           return "Xiaomi"
    if "huawei" in v:           return "Huawei"
    if "lg" in v:               return "LG device"
    if "sony" in v:             return "Sony device"
    if "intel" in v:            return "PC (Intel Wi-Fi)"
    if has(80) or has(443) or has(8080): return "web device"
    return "?"


# ══════════════════════════════════════════════════════════════════
#  ОСНОВНОЙ СКАН
# ══════════════════════════════════════════════════════════════════

def _show_copy_screen(emit, lines):
    """Отправляет main.py запрос открыть модал копирования."""
    try:
        payload = json.dumps({
            "title": "netscan — клик по строке, чтобы скопировать",
            "lines": lines,
        }, ensure_ascii=False)
        emit(f"@@COPY_SCREEN@@{payload}")
    except Exception:
        pass


def _cmd_scan(emit, mode: str, should_stop):
    emit("")

    my_ip = _get_my_ip()
    if not my_ip:
        emit("[#c93a3a]◆ не могу определить свой IP — нет сети?[/]")
        return

    gw_ip = _get_gw()
    base  = my_ip.rsplit(".", 1)[0]

    emit(f"[#a06cd5]◆ мой IP:[/]   [b]{my_ip}[/]")
    emit(f"[#a06cd5]◆ шлюз:[/]     [b]{gw_ip}[/]")
    emit(f"[#a06cd5]◆ подсеть:[/]  [b]{base}.0/24[/]")
    emit(f"[#a06cd5]◆ режим:[/]    [b]{mode}[/]")
    emit("")

    if mode == "fast":
        emit(f"[#5a2a82]◆ [1/2] пингую {base}.1-254…[/]")
        _ping_sweep(base)
        entries = _arp_table()
    else:
        emit(f"[#5a2a82]◆ [1/4] пингую {base}.1-254…[/]")
        _ping_sweep(base)
        if should_stop(): return

        emit("[#5a2a82]◆ [2/4] UDP-broadcast…[/]")
        _udp_broadcast_probe(my_ip)
        _ssdp_mcast()
        time.sleep(0.7)
        if should_stop(): return

        emit("[#5a2a82]◆ [3/4] ещё раз…[/]")
        _udp_broadcast_probe(my_ip)
        time.sleep(0.4)
        entries = _arp_table()

    in_subnet = [(ip, mac) for ip, mac in entries if ip.startswith(base + ".")]

    seen_macs = set()
    dedup = []
    for ip, mac in in_subnet:
        if mac in seen_macs:
            continue
        seen_macs.add(mac)
        dedup.append((ip, mac))

    if not dedup:
        emit("")
        emit("[#c93a3a]◆ устройств не найдено[/]")
        emit("[#5a2a82]  → проверь, что ты в локальной сети[/]")
        return

    if mode != "fast":
        emit("")
        emit(f"[#5a2a82]◆ определяю тип {len(dedup)} устройств…[/]")

    devices = []
    for idx, (ip, mac) in enumerate(dedup, 1):
        if should_stop(): return
        ports = []
        if mode != "fast":
            ports = _scan_ports_for(ip)
            emit(f"  [#5a2a82][{idx:>2}/{len(dedup)}][/] "
                 f"[b]{ip:<15}[/b] [dim]{mac}[/]")
        devices.append({
            "ip": ip, "mac": mac,
            "vendor": _vendor_for(mac),
            "ports": ports,
            "is_gw": (ip == gw_ip),
            "is_me": (ip == my_ip),
        })

    devices.sort(key=lambda d: tuple(int(p) for p in d["ip"].split(".")))

    emit("")
    emit("[#c93a3a][b]◆ УСТРОЙСТВА В СЕТИ[/b][/]")
    emit("")

    for d in devices:
        tag = ""
        if d["is_me"]: tag = " [#5a2a82]← ты[/]"
        elif d["is_gw"]: tag = " [#5a2a82]← роутер[/]"
        dtype = _guess_type(d["vendor"], d["ports"], d["is_gw"])
        emit(f"  [#e94b4b][b]{d['ip']:<15}[/b][/]  "
             f"[dim]{d['mac']}[/]  "
             f"[#b794f4]{d['vendor']:<12}[/]  "
             f"[#a06cd5]{dtype:<15}[/]{tag}")
        if d["ports"]:
            pstr = ", ".join(str(p) for p in d["ports"][:8])
            if len(d["ports"]) > 8:
                pstr += f", +{len(d['ports'])-8}"
            emit(f"                  [#2b0f3a]порты:[/] [dim]{pstr}[/]")

    emit("")
    emit(f"[#5a2a82]◆ всего устройств: [b]{len(devices)}[/b][/]")

    # ─── строки для модала ───
    lines = []
    lines.append("=" * 66)
    lines.append("  ABADON SOFT — устройства в сети")
    lines.append("=" * 66)
    lines.append(f"  Мой IP:   {my_ip}")
    lines.append(f"  Шлюз:     {gw_ip}")
    lines.append(f"  Подсеть:  {base}.0/24")
    lines.append(f"  Найдено:  {len(devices)} устройств")
    lines.append("")
    lines.append(f"  {'IP':<15}  {'MAC':<17}  {'VENDOR':<12}  {'TYPE':<16}  PORTS")
    lines.append("  " + "-" * 90)
    for d in devices:
        dtype = _guess_type(d["vendor"], d["ports"], d["is_gw"])
        tag = ""
        if d["is_me"]:   tag = "  [ты]"
        elif d["is_gw"]: tag = "  [роутер]"
        pstr = ",".join(str(p) for p in d["ports"][:8]) if d["ports"] else ""
        lines.append(
            f"  {d['ip']:<15}  {d['mac']:<17}  {d['vendor']:<12}  "
            f"{dtype:<16}  {pstr}{tag}"
        )
    lines.append("")
    lines.append("=" * 66)

    _LAST_RESULT["lines"] = lines

    # файл — на всякий случай
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.dirname(here)
        path = os.path.join(root, "netscan_results.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        _LAST_RESULT["path"] = path
        emit(f"[#5a2a82]◆ также сохранено в:[/] [dim]{path}[/]")
    except Exception:
        pass

    emit("")
    emit("[#e94b4b]◆ открываю окно копирования…[/]")
    emit("[#a06cd5]◆ кликни по нужной строке чтобы скопировать её[/]")
    emit("")

    _show_copy_screen(emit, lines)


def _cmd_copy(emit):
    lines = _LAST_RESULT.get("lines", [])
    if not lines:
        emit("[#c93a3a]◆ сначала сделай скан:[/] [b]netscan[/b]")
        return
    emit("[#e94b4b]◆ открываю окно копирования…[/]")
    _show_copy_screen(emit, lines)


def _cmd_save(emit):
    lines = _LAST_RESULT.get("lines", [])
    if not lines:
        emit("[#c93a3a]◆ сначала сделай скан:[/] [b]netscan[/b]")
        return
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.dirname(here)
        path = os.path.join(root, "netscan_results.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        emit(f"[#e94b4b]◆ сохранено в:[/] [b]{path}[/]")
    except Exception as e:
        emit(f"[#c93a3a]◆ ошибка сохранения: {e}[/]")


# ══════════════════════════════════════════════════════════════════
#  ТОЧКА ВХОДА
# ══════════════════════════════════════════════════════════════════

def run(args: str, emit, invoked_as: str = None, should_stop=None):
    if should_stop is None:
        should_stop = lambda: False

    args = (args or "").strip().lower()

    if args in ("", "full", "deep", "d", "all"):
        _cmd_scan(emit, "full", should_stop); return
    if args in ("fast", "f", "quick", "q"):
        _cmd_scan(emit, "fast", should_stop); return
    if args in ("copy", "c", "cp"):
        _cmd_copy(emit); return
    if args in ("save", "s"):
        _cmd_save(emit); return
    if args in ("help", "?", "h"):
        emit("[#c93a3a]◆ использование:[/]")
        emit("  [b]netscan[/b]         — полный скан")
        emit("  [b]netscan fast[/b]    — только ping, быстро")
        emit("  [b]netscan copy[/b]    — открыть окно копирования")
        emit("  [b]netscan save[/b]    — сохранить в файл")
        emit("")
        emit("[#5a2a82]◆ после скана откроется окно:[/]")
        emit("  • клик по строке — копирует её в буфер")
        emit("  • верхняя строка — копирует всё целиком")
        emit("")
        return

    emit(f"[#c93a3a]◆ неизвестный режим:[/] {args}")
    emit("[#5a2a82]  → netscan | fast | copy | save | help[/]")